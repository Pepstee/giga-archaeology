"""Deterministic admission and acceptance boundary for GIGA v2 development.

The gate intentionally uses only the Python standard library. It does not try to
control every keystroke made by a process with full filesystem access. Instead,
it makes constitutional admission and candidate verification mandatory at the
official integration boundary.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import re
import stat
import subprocess
import sys
from pathlib import Path
from typing import Any, Iterable, NamedTuple


WORK_ORDER_SCHEMA = "giga-v2.work-order.v2"
LANE_SCHEMA = "giga-v2.lane-registry.v1"
LOCK_SCHEMA = "giga-v2.constitution-lock.v1"
PREFLIGHT_SCHEMA = "giga-v2.preflight-receipt.v1"
COMPLETION_SCHEMA = "giga-v2.completion-receipt.v2"
ATTESTATION_SCHEMA = "giga-v2.candidate-attestation.v1"
STEWARDSHIP_SCHEMA = "giga-v2.development-stewardship.v3"
STEWARDSHIP_POLICY_PATH = "contracts/constitution/development-stewardship.v3.json"
PRIOR_STEWARDSHIP_SCHEMA = "giga-v2.development-stewardship.v2"
ARCHITECTURE_CATALOGUE_PATH = "control/architecture-catalogue.json"
AUTHORITY_SOURCE_DIRECTORY = "contracts/constitution/authority-sources/sha256"
PORTABLE_AMENDMENT_SCHEMA = "giga-v2.portable-authority-amendment.v1"
PORTABLE_AMENDMENT_PATH = "contracts/constitution/amendments/2026-08-24-portable-authority.v1.json"
RATIFIED_BASE_COMMIT = "396c34c92e5add3a63e41c66217613a9368e267a"
RATIFIED_BASE_TREE = "f81261d96d328bc189d04c812f0a2b5d7befb2a9"
RATIFIED_AMENDMENT_CONTRACT_SHA256 = "4915f03cbf43685bee098cd563f438f09cbb8e7566e06abcdfbd92f39aefd6db"
PRIOR_STEWARDSHIP_POLICY_SHA256 = "9329b98efaba7d429ab4b93d8c4fb86ce95236241f62475fbad7aafe88e00799"
RATIFIED_STEWARDSHIP_V3_POLICY_SHA256 = "55e5b729f8d18b9c61699319caf65091fbc343a17f9b2070cc9880b1a795ab87"
RATIFIED_AMENDMENT_RECORDED_AT = "2026-08-24T00:00:00Z"
LOCAL_VERIFY_RUNNER_PATH = "giga_control/extensions/local_verify.py"
RATIFIED_LOCAL_VERIFY_RUNNER_SHA256 = "1570400a4095bec8135f66d96ead27337146d00d95291415d0a84de0bf52b932"
CANDIDATE_ALLOWLIST_ACTIONS = {
    "contracts/constitution/authority-sources/sha256/fc65e8221416178eb3c7ef2801b4e631269853926a648683648dc7cc293dc245.md": "add",
    "contracts/constitution/authority-sources/sha256/eebb08490dcba120f793f4a5c513a71accefa0d4871c2b05f24d8d1d6a3ae6a8.md": "add",
    "contracts/constitution/development-stewardship.v3.json": "add",
    PORTABLE_AMENDMENT_PATH: "add",
    "contracts/constitution/local-verification.v2.json": "add",
    "tests/constitution/test_stewardship_v3.py": "add",
    "giga_control/gate.py": "modify",
    "control/protected-paths.json": "modify",
    "giga_control/extensions/local_verify.py": "modify",
    "tests/constitution/test_gate.py": "modify",
    "tests/constitution/test_local_verification.py": "modify",
    "contracts/constitution/development-stewardship.v2.json": "delete",
    "contracts/constitution/local-verification.v1.json": "delete",
    "tests/constitution/test_stewardship_v2.py": "delete",
}
DENIED_AMENDMENT_AUTHORITY = {
    "external_writes": False,
    "future_constitution_amendments": False,
    "identity_representation": False,
    "irreversible_actions": False,
    "protected_integration": False,
    "runtime_deployment": False,
    "spending": False,
    "vault_access": False,
}
EXPECTED_OPERATOR_GOAL_SHA256 = "54b2de237f53b65b497ab11bf7dbde602029045e3b90fc35d2ec2a2cc3590ed6"
MAX_RUNTIME_SECONDS = 24 * 60 * 60
DEFAULT_UNATTENDED_SECONDS = 4 * 60 * 60
ID_PATTERN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,127}$")
VERSION_PATTERN = re.compile(r"(?im)^\*\*Version:\*\*\s*([0-9]+(?:\.[0-9]+)*)\s*$")
SECRET_PATTERNS = (
    re.compile(rb"-----BEGIN (?:RSA |EC |DSA |OPENSSH |PGP )?PRIVATE KEY-----"),
    re.compile(rb"AKIA[0-9A-Z]{16}"),
    re.compile(rb"gh[pousr]_[A-Za-z0-9]{32,}"),
    re.compile(rb"sk-[A-Za-z0-9_-]{20,}"),
    re.compile(rb"xox[baprs]-[A-Za-z0-9-]{16,}"),
)
OUTCOME_CLASSES = {"ADOPT", "CONFIGURE", "REPAIR", "EXTEND", "WRAP", "BUILD", "DROP"}
PROOF_CATEGORIES = {"focused-positive", "negative", "regression", "system", "rollback"}
RATIFIED_PROTECTED_PATHS = (
    "AGENTS.md",
    "README.md",
    "CONSTITUTION.md",
    "control/architecture-catalogue.json",
    "control/constitution.lock.json",
    "control/lanes.json",
    "control/protected-paths.json",
    ".githooks",
    "giga_control/cli.py",
    "giga_control/gate.py",
    "contracts/constitution/DEVELOPMENT_STEWARDSHIP.md",
    "contracts/constitution/development-stewardship.v3.json",
    "contracts/constitution/authority-sources",
    "contracts/constitution/amendments",
    "tests/constitution/test_gate.py",
    "tests/constitution/test_stewardship_v3.py",
    "work_orders/TEMPLATE.json",
)
RATIFIED_ARCHITECTURE_SOURCES = (
    {
        "role": "sovereign-architecture",
        "name": "Jarvis sovereign runtime proposed architecture",
        "sha256": "fc65e8221416178eb3c7ef2801b4e631269853926a648683648dc7cc293dc245",
        "bytes": 65781,
    },
    {
        "role": "implementation-blueprint",
        "name": "Jarvis sovereign runtime implementation blueprint",
        "sha256": "eebb08490dcba120f793f4a5c513a71accefa0d4871c2b05f24d8d1d6a3ae6a8",
        "bytes": 97251,
    },
)
RATIFIED_BASE_DELETE_BINDINGS = {
    "contracts/constitution/development-stewardship.v2.json": {
        "mode": "100644",
        "sha256": "17f10959364f49898d4f91af1f1726553e3d9bb41e018629a79e9c040d872f61",
    },
    "contracts/constitution/local-verification.v1.json": {
        "mode": "100644",
        "sha256": "a43cb3c2b5fa8f9e60d9a59f6ac9bc005eacead9cd52af7bcc9a251ca402ef10",
    },
    "tests/constitution/test_stewardship_v2.py": {
        "mode": "100644",
        "sha256": "c28d1295df20d216170663a3b2ff676a9d9abb45c6b916caae28074273069135",
    },
}


class GateError(ValueError):
    """A deterministic policy rejection."""


def canonical(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=True, separators=(",", ":"), sort_keys=True).encode()


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def digest(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def load_object(path: Path) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise GateError(f"cannot load JSON object {path}: {exc}") from exc
    if not isinstance(value, dict):
        raise GateError(f"JSON root must be an object: {path}")
    return value


def _reject_duplicate_keys(pairs: list[tuple[str, Any]]) -> dict[str, Any]:
    result: dict[str, Any] = {}
    for key, value in pairs:
        if key in result:
            raise GateError(f"duplicate JSON object key: {key}")
        result[key] = value
    return result


def parse_strict_json(text: str, location: str) -> Any:
    try:
        return json.loads(text, object_pairs_hook=_reject_duplicate_keys)
    except json.JSONDecodeError as exc:
        raise GateError(f"{location} is not valid JSON: {exc}") from exc


def load_strict_object(path: Path) -> dict[str, Any]:
    try:
        text = path.read_text(encoding="utf-8")
    except OSError as exc:
        raise GateError(f"cannot load JSON object {path}: {exc}") from exc
    value = parse_strict_json(text, str(path))
    if not isinstance(value, dict):
        raise GateError(f"JSON root must be an object: {path}")
    return value


def load_strict_object_bound(root: Path, relative: str) -> dict[str, Any]:
    """Strictly decode a repository-owned JSON authority object through the
    descriptor-relative O_NOFOLLOW seam so no external bytes can enter through
    a substituted parent component."""
    snapshot = open_bound_authority_snapshot(root, relative)
    try:
        data = finish_bound_authority_read(snapshot)
    finally:
        close_bound_authority_snapshot(snapshot)
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise GateError(f"authority JSON object is not UTF-8: {relative}") from exc
    value = parse_strict_json(text, relative)
    if not isinstance(value, dict):
        raise GateError(f"JSON root must be an object: {relative}")
    return value


def write_object(path: Path, value: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def self_bound(value: dict[str, Any]) -> dict[str, Any]:
    result = dict(value)
    result["receipt_sha256"] = sha256_bytes(canonical(result))
    return result


def valid_self_hash(value: dict[str, Any]) -> bool:
    claimed = value.get("receipt_sha256")
    body = dict(value)
    body.pop("receipt_sha256", None)
    return isinstance(claimed, str) and claimed == sha256_bytes(canonical(body))


def utc_now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def timestamp(value: dt.datetime | None = None) -> str:
    return (value or utc_now()).isoformat().replace("+00:00", "Z")


def parse_timestamp(value: Any, location: str) -> dt.datetime:
    if not isinstance(value, str):
        raise GateError(f"{location} must be an RFC3339 timestamp")
    try:
        parsed = dt.datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError as exc:
        raise GateError(f"{location} must be an RFC3339 timestamp") from exc
    if parsed.tzinfo is None:
        raise GateError(f"{location} must include a timezone")
    return parsed.astimezone(dt.timezone.utc)


def find_root(start: Path | None = None) -> Path:
    current = (start or Path.cwd()).resolve()
    for candidate in (current, *current.parents):
        if (candidate / "CONSTITUTION.md").is_file() and (candidate / "control/lanes.json").is_file():
            return candidate
    raise GateError("not inside a GIGA v2 project")


def normal_relative(value: Any, location: str, *, allow_dot: bool = False) -> str:
    if allow_dot and value == ".":
        return "."
    if not isinstance(value, str) or not value or "\x00" in value:
        raise GateError(f"{location} must be a non-empty relative path")
    path = Path(value)
    if path.is_absolute() or any(part in {"", ".", ".."} for part in path.parts):
        raise GateError(f"{location} must be a normal relative path")
    if path.parts[0] == ".git":
        raise GateError(f"{location} may not address .git")
    return path.as_posix()


def strict_keys(value: dict[str, Any], required: set[str], optional: set[str], location: str) -> None:
    missing = sorted(required - value.keys())
    extra = sorted(value.keys() - required - optional)
    if missing:
        raise GateError(f"{location} missing fields: {', '.join(missing)}")
    if extra:
        raise GateError(f"{location} contains unknown fields: {', '.join(extra)}")


def constitution_identity(root: Path) -> dict[str, str]:
    path = root / "CONSTITUTION.md"
    match = VERSION_PATTERN.search(path.read_text(encoding="utf-8"))
    if not match:
        raise GateError("CONSTITUTION.md has no machine-readable version")
    return {"version": match.group(1), "sha256": digest(path)}


def nonempty_text(value: Any, location: str, *, minimum: int = 1) -> str:
    if not isinstance(value, str) or len(value.strip()) < minimum:
        raise GateError(f"{location} must contain at least {minimum} non-whitespace characters")
    lowered = value.strip().lower()
    if lowered.startswith(("replace with ", "placeholder:", "todo:", "tbd:", "fill me")):
        raise GateError(f"{location} contains placeholder text")
    return value.strip()


def nonempty_text_list(value: Any, location: str, *, minimum_items: int = 1) -> list[str]:
    if not isinstance(value, list) or len(value) < minimum_items:
        raise GateError(f"{location} must contain at least {minimum_items} entries")
    return [nonempty_text(item, f"{location}[{index}]", minimum=12) for index, item in enumerate(value)]


def _string_ids(value: Any, location: str) -> list[str]:
    if not isinstance(value, list) or not value:
        raise GateError(f"{location} must contain at least one identifier")
    result: list[str] = []
    for index, item in enumerate(value):
        if not isinstance(item, str) or not ID_PATTERN.fullmatch(item):
            raise GateError(f"{location}[{index}] is not a valid identifier")
        result.append(item)
    if len(result) != len(set(result)):
        raise GateError(f"{location} contains duplicates")
    return result


def valid_numbered_id(value: Any, prefix: str, minimum: int, maximum: int, location: str) -> str:
    width = 3 if prefix == "JSR-" else 1 if prefix == "L" else 2
    pattern = rf"{re.escape(prefix)}[0-9]{{{width}}}"
    if not isinstance(value, str) or not re.fullmatch(pattern, value):
        raise GateError(f"{location} has invalid format")
    number = int(value[len(prefix) :])
    if not minimum <= number <= maximum:
        raise GateError(f"{location} is outside the ratified {minimum}..{maximum} range")
    return value


def mentions_identifier(text: str, identifier: str) -> bool:
    return re.search(rf"(?<![A-Za-z0-9]){re.escape(identifier)}(?![A-Za-z0-9])", text) is not None


def _policy_self_hash(value: dict[str, Any]) -> str:
    body = dict(value)
    body.pop("policy_sha256", None)
    return sha256_bytes(canonical(body))


def stewardship_policy(root: Path) -> dict[str, Any]:
    policy = load_strict_object_bound(root, STEWARDSHIP_POLICY_PATH)
    strict_keys(
        policy,
        {
            "schema",
            "version",
            "status",
            "recorded_at",
            "constitution",
            "document",
            "goal_authority",
            "architecture_target",
            "stewardship",
            "ai_control_fields",
            "work_order_schema",
            "policy_sha256",
        },
        set(),
        "development stewardship policy",
    )
    if policy["schema"] != STEWARDSHIP_SCHEMA or policy["status"] != "ACTIVE":
        raise GateError("development stewardship policy is not active v3")
    if policy["version"] != "3.0.0":
        raise GateError("development stewardship policy version must be exactly 3.0.0")
    if policy["policy_sha256"] != _policy_self_hash(policy):
        raise GateError("development stewardship policy self-hash is invalid")
    if policy["constitution"] != constitution_identity(root):
        raise GateError("development stewardship policy has a stale Constitution binding")
    if policy["work_order_schema"] != WORK_ORDER_SCHEMA:
        raise GateError("development stewardship policy names a different work-order schema")

    document = policy["document"]
    if not isinstance(document, dict):
        raise GateError("development stewardship document binding must be an object")
    strict_keys(document, {"path", "sha256"}, set(), "development stewardship document")
    document_path = root / normal_relative(document["path"], "development stewardship document.path")
    if not document_path.is_file() or digest(document_path) != document["sha256"]:
        raise GateError("development stewardship document binding is missing or stale")

    goal_authority = policy["goal_authority"]
    if not isinstance(goal_authority, dict):
        raise GateError("goal_authority must be an object")
    strict_keys(goal_authority, {"operator", "thread_id", "objective_sha256"}, set(), "goal_authority")
    if goal_authority["operator"] != "Artiom Gutu" or goal_authority["objective_sha256"] != EXPECTED_OPERATOR_GOAL_SHA256:
        raise GateError("development stewardship goal authority is invalid")

    target = policy["architecture_target"]
    if not isinstance(target, dict):
        raise GateError("architecture_target must be an object")
    strict_keys(
        target,
        {
            "sources",
            "requirement_range",
            "law_range",
            "layer_range",
            "slice_catalogue",
            "modes",
            "ownership_invariants",
        },
        set(),
        "architecture_target",
    )
    sources = target["sources"]
    if not isinstance(sources, list) or len(sources) != len(RATIFIED_ARCHITECTURE_SOURCES):
        raise GateError("architecture target must bind the proposal and blueprint descriptors exactly")
    for index, (source, ratified) in enumerate(zip(sources, RATIFIED_ARCHITECTURE_SOURCES)):
        if not isinstance(source, dict):
            raise GateError(f"architecture source {index} must be an object")
        strict_keys(source, {"role", "name", "repository_path", "sha256", "bytes"}, set(), f"architecture source {index}")
        if source["role"] != ratified["role"]:
            raise GateError(f"architecture source {index} role does not match the ratified descriptor order")
        if source["name"] != ratified["name"]:
            raise GateError(f"architecture source {index} name differs from the ratified identity")
        if not isinstance(source["sha256"], str) or re.fullmatch(r"[0-9a-f]{64}", source["sha256"]) is None:
            raise GateError(f"architecture source {index} has an invalid hash")
        if source["sha256"] != ratified["sha256"]:
            raise GateError(f"architecture source {index} hash differs from the ratified identity")
        if isinstance(source["bytes"], bool) or not isinstance(source["bytes"], int) or source["bytes"] != ratified["bytes"]:
            raise GateError(f"architecture source {index} size differs from the ratified identity")
        repository_path = normal_relative(source["repository_path"], f"architecture source {index}.repository_path")
        if repository_path != f"{AUTHORITY_SOURCE_DIRECTORY}/{ratified['sha256']}.md":
            raise GateError(f"architecture source {index} repository path escapes the owned authority-source directory")
        data = read_bound_authority_source(root, repository_path, source["bytes"])
        if sha256_bytes(data) != ratified["sha256"]:
            raise GateError(f"present architecture source differs from the ratified identity: {repository_path}")
    if policy["ai_control_fields"] != [
        "hallucination",
        "scope_drift",
        "context_bloat",
        "tunnel_vision",
        "failure_forecast",
        "sanity_check",
    ]:
        raise GateError("development stewardship AI controls are incomplete or reordered")
    if policy["policy_sha256"] != RATIFIED_STEWARDSHIP_V3_POLICY_SHA256:
        raise GateError("development stewardship policy differs from the ratified v3 identity")
    return policy


class BoundSourceSnapshot(NamedTuple):
    root_path: Path
    root_fd: int
    directory_fd: int
    file_fd: int
    name: str
    metadata: os.stat_result
    relative: str
    size: int
    root_metadata: os.stat_result


def _source_fingerprint(value: os.stat_result) -> tuple[int, int, int, int, int, int]:
    return (value.st_dev, value.st_ino, value.st_mode, value.st_nlink, value.st_size, value.st_mtime_ns)


def _open_nofollow(directory_fd: int, name: str, *, want_directory: bool) -> int:
    flags = os.O_RDONLY | getattr(os, "O_CLOEXEC", 0) | getattr(os, "O_NOFOLLOW", 0)
    if want_directory:
        flags |= os.O_DIRECTORY
    return os.open(name, flags, dir_fd=directory_fd)


def close_bound_authority_snapshot(snapshot: BoundSourceSnapshot) -> None:
    for descriptor in (snapshot.file_fd, snapshot.directory_fd, snapshot.root_fd):
        try:
            os.close(descriptor)
        except OSError:
            pass


def open_bound_authority_snapshot(
    root: Path, relative: str, bound_bytes: int | None = None
) -> BoundSourceSnapshot:
    """Open one authority/payload file by descriptor-relative O_NOFOLLOW traversal.

    The final object must be a regular single-link file. With ``bound_bytes`` the
    size is fixed before reading; otherwise the captured size becomes the read
    bound. Every filesystem failure becomes a stable ``GateError``, and no byte
    is ever read through a substituted parent component.
    """
    root_fd: int | None = None
    directory_fd: int | None = None
    file_fd: int | None = None
    try:
        resolved_root = root.resolve(strict=True)
        root_fd = os.open(resolved_root, os.O_RDONLY | os.O_DIRECTORY | getattr(os, "O_CLOEXEC", 0))
        opened_root = os.fstat(root_fd)
        components = normal_relative(relative, "authority source").split("/")
        directory_fd = os.dup(root_fd)
        for component in components[:-1]:
            next_fd = _open_nofollow(directory_fd, component, want_directory=True)
            os.close(directory_fd)
            directory_fd = next_fd
        name = components[-1]
        file_fd = _open_nofollow(directory_fd, name, want_directory=False)
        metadata = os.fstat(file_fd)
        if not stat.S_ISREG(metadata.st_mode):
            raise GateError(f"authority source is not a regular file: {relative}")
        if metadata.st_nlink != 1:
            raise GateError(f"authority source must have exactly one hard link: {relative}")
        if bound_bytes is not None and metadata.st_size != bound_bytes:
            raise GateError(f"authority source size differs from its bound descriptor: {relative}")
        return BoundSourceSnapshot(
            root_path=resolved_root,
            root_fd=root_fd,
            directory_fd=directory_fd,
            file_fd=file_fd,
            name=name,
            metadata=metadata,
            relative=relative,
            size=metadata.st_size,
            root_metadata=opened_root,
        )
    except GateError:
        if file_fd is not None:
            os.close(file_fd)
        if directory_fd is not None:
            os.close(directory_fd)
        if root_fd is not None:
            os.close(root_fd)
        raise
    except OSError as exc:
        if file_fd is not None:
            os.close(file_fd)
        if directory_fd is not None:
            os.close(directory_fd)
        if root_fd is not None:
            os.close(root_fd)
        raise GateError(f"authority source is missing, linked or unreadable: {relative}") from exc


def _read_exact_from_snapshot(snapshot: BoundSourceSnapshot) -> bytes:
    chunks: list[bytes] = []
    total = 0
    while total < snapshot.size:
        chunk = os.read(snapshot.file_fd, snapshot.size - total)
        if not chunk:
            raise GateError(f"authority source ended before its bound size: {snapshot.relative}")
        chunks.append(chunk)
        total += len(chunk)
    if os.read(snapshot.file_fd, 1):
        raise GateError(f"authority source exceeds its bound size while reading: {snapshot.relative}")
    return b"".join(chunks)


def _verify_opened_authority_snapshot(snapshot: BoundSourceSnapshot) -> None:
    try:
        after = os.fstat(snapshot.file_fd)
        entry = os.stat(snapshot.name, dir_fd=snapshot.directory_fd, follow_symlinks=False)
        current_root = os.stat(snapshot.root_path, follow_symlinks=False)
    except OSError as exc:
        raise GateError(f"authority source changed while reading: {snapshot.relative}") from exc
    if _source_fingerprint(after) != _source_fingerprint(snapshot.metadata):
        raise GateError(f"authority source changed while reading: {snapshot.relative}")
    if (entry.st_dev, entry.st_ino) != (snapshot.metadata.st_dev, snapshot.metadata.st_ino):
        raise GateError(f"authority source was substituted while reading: {snapshot.relative}")
    if not stat.S_ISREG(entry.st_mode) or entry.st_nlink != 1:
        raise GateError(f"authority source became linked or invalid while reading: {snapshot.relative}")
    if (current_root.st_dev, current_root.st_ino) != (
        snapshot.root_metadata.st_dev,
        snapshot.root_metadata.st_ino,
    ):
        raise GateError(f"repository root was substituted while reading: {snapshot.relative}")
    rewalk_file_fd: int | None = None
    rewalk_directory_fd: int | None = None
    try:
        rewalk_directory_fd = os.dup(snapshot.root_fd)
        for component in snapshot.relative.split("/")[:-1]:
            next_fd = _open_nofollow(rewalk_directory_fd, component, want_directory=True)
            os.close(rewalk_directory_fd)
            rewalk_directory_fd = next_fd
        rewalk_file_fd = _open_nofollow(rewalk_directory_fd, snapshot.name, want_directory=False)
        current = os.fstat(rewalk_file_fd)
    except OSError as exc:
        raise GateError(f"canonical authority-source path became unreadable: {snapshot.relative}") from exc
    finally:
        if rewalk_file_fd is not None:
            os.close(rewalk_file_fd)
        if rewalk_directory_fd is not None:
            os.close(rewalk_directory_fd)
    if (current.st_dev, current.st_ino) != (snapshot.metadata.st_dev, snapshot.metadata.st_ino):
        raise GateError(f"canonical authority-source path was replaced while reading: {snapshot.relative}")
    if _source_fingerprint(current) != _source_fingerprint(snapshot.metadata):
        raise GateError(f"canonical authority-source content changed while reading: {snapshot.relative}")


def finish_bound_authority_read(snapshot: BoundSourceSnapshot) -> bytes:
    """Read exactly the bound byte count, then verify pre/post and rewalk identity."""
    try:
        data = _read_exact_from_snapshot(snapshot)
        _verify_opened_authority_snapshot(snapshot)
        return data
    except OSError as exc:
        raise GateError(f"authority source became unreadable while reading: {snapshot.relative}") from exc


def read_bound_authority_source(root: Path, relative: str, bound_bytes: int) -> bytes:
    snapshot = open_bound_authority_snapshot(root, relative, bound_bytes)
    try:
        return finish_bound_authority_read(snapshot)
    finally:
        close_bound_authority_snapshot(snapshot)


def portable_amendment_record(root: Path, policy: dict[str, Any]) -> dict[str, Any]:
    """Validate the self-bound provenance-only portable-authority record."""
    record = load_strict_object_bound(root, PORTABLE_AMENDMENT_PATH)
    strict_keys(
        record,
        {
            "schema",
            "id",
            "recorded_at",
            "mode",
            "reusable",
            "base",
            "contract_evidence",
            "prior_policy_identity",
            "successor_policy_identity",
            "authority",
            "candidate_manifest",
            "amendment_sha256",
        },
        set(),
        "portable-authority amendment record",
    )
    body = dict(record)
    claimed_self_hash = body.pop("amendment_sha256")
    if not isinstance(claimed_self_hash, str) or claimed_self_hash != sha256_bytes(canonical(body)):
        raise GateError("portable-authority amendment self-hash is invalid")
    if (
        record["schema"] != PORTABLE_AMENDMENT_SCHEMA
        or record["id"] != "2026-08-24-portable-authority"
        or record["mode"] != "candidate-preparation-only"
    ):
        raise GateError("portable-authority amendment identity is invalid")
    if record["reusable"] is not False:
        raise GateError("portable-authority amendment is provenance-only and may not be reusable")
    if record["recorded_at"] != RATIFIED_AMENDMENT_RECORDED_AT:
        raise GateError("portable-authority amendment recorded_at differs from the ratified provenance")
    if record["base"] != {"commit": RATIFIED_BASE_COMMIT, "tree": RATIFIED_BASE_TREE}:
        raise GateError("portable-authority amendment base binding is stale")
    contract_evidence = record["contract_evidence"]
    if not isinstance(contract_evidence, dict):
        raise GateError("portable-authority contract evidence must be an object")
    strict_keys(contract_evidence, {"path", "sha256"}, set(), "portable-authority contract evidence")
    if contract_evidence != {
        "path": ".git/ox-contracts/portable-authority-v3.md",
        "sha256": RATIFIED_AMENDMENT_CONTRACT_SHA256,
    }:
        raise GateError("portable-authority amendment contract evidence is stale")
    prior = record["prior_policy_identity"]
    if not isinstance(prior, dict):
        raise GateError("portable-authority prior policy identity must be an object")
    strict_keys(prior, {"schema", "version", "policy_sha256"}, set(), "portable-authority prior policy identity")
    if prior != {
        "schema": PRIOR_STEWARDSHIP_SCHEMA,
        "version": "2.0.0",
        "policy_sha256": PRIOR_STEWARDSHIP_POLICY_SHA256,
    }:
        raise GateError("portable-authority amendment prior policy identity is stale")
    successor = record["successor_policy_identity"]
    if not isinstance(successor, dict):
        raise GateError("portable-authority successor policy identity must be an object")
    strict_keys(successor, {"schema", "version", "policy_sha256"}, set(), "portable-authority successor policy identity")
    if successor != {
        "schema": STEWARDSHIP_SCHEMA,
        "version": policy["version"],
        "policy_sha256": policy["policy_sha256"],
    }:
        raise GateError("portable-authority amendment successor policy identity differs from the active v3 policy")
    if record["authority"] != DENIED_AMENDMENT_AUTHORITY:
        raise GateError("portable-authority amendment carries authority that must stay denied")
    manifest = record["candidate_manifest"]
    expected_paths = [path for path in sorted(CANDIDATE_ALLOWLIST_ACTIONS) if path != PORTABLE_AMENDMENT_PATH]
    if not isinstance(manifest, list) or not all(isinstance(entry, dict) for entry in manifest):
        raise GateError("candidate manifest must be an ordered list of objects")
    if [entry.get("path") for entry in manifest] != expected_paths:
        raise GateError(
            "candidate manifest must list exactly the ratified allowlist minus the amendment record itself"
        )
    for entry, expected_path in zip(manifest, expected_paths):
        action = CANDIDATE_ALLOWLIST_ACTIONS[expected_path]
        strict_keys(entry, {"action", "mode", "path", "sha256"}, set(), f"candidate manifest {expected_path}")
        if entry["action"] != action or entry["path"] != expected_path:
            raise GateError(f"candidate manifest action differs from the ratified allowlist: {expected_path}")
        if entry["mode"] not in {"100644", "100755"} or not isinstance(entry["sha256"], str):
            raise GateError(f"candidate manifest binding is malformed: {expected_path}")
        if re.fullmatch(r"[0-9a-f]{64}", entry["sha256"]) is None:
            raise GateError(f"candidate manifest hash is malformed: {expected_path}")
        if action == "delete":
            ratified = RATIFIED_BASE_DELETE_BINDINGS.get(expected_path)
            if ratified is None:
                raise GateError(f"delete manifest entry has no ratified base binding: {expected_path}")
            if entry["mode"] != ratified["mode"] or entry["sha256"] != ratified["sha256"]:
                raise GateError(
                    f"delete manifest entry differs from the ratified base blob binding: {expected_path}"
                )
            target = root / expected_path
            if target.is_symlink() or target.exists():
                raise GateError(f"superseded delete target must be absent: {expected_path}")
            continue
        try:
            snapshot = open_bound_authority_snapshot(root, expected_path)
            try:
                data = finish_bound_authority_read(snapshot)
            finally:
                close_bound_authority_snapshot(snapshot)
        except OSError as exc:
            raise GateError(f"candidate payload drifted from its amendment binding: {expected_path}") from exc
        observed_mode = "100755" if snapshot.metadata.st_mode & 0o111 else "100644"
        if observed_mode != entry["mode"] or sha256_bytes(data) != entry["sha256"]:
            raise GateError(f"candidate payload drifted from its amendment binding: {expected_path}")
        if (
            expected_path == LOCAL_VERIFY_RUNNER_PATH
            and entry["sha256"] != RATIFIED_LOCAL_VERIFY_RUNNER_SHA256
        ):
            raise GateError("local verifier implementation differs from the ratified portable profile")
    return record


def validate_candidate_preparation_diff(root: Path) -> dict[str, Any]:
    """Candidate-preparation-only proof that the ACTUAL working diff equals the
    ratified 14-path allowlist exactly, against the exact ratified base identity.

    This seam is deliberately NOT part of permanent foundation logic: after
    protected integration the repository HEAD legitimately advances past the
    ratified base, so it must only be invoked while an uncommitted portable-
    authority candidate is under preparation.
    """
    policy = stewardship_policy(root)
    head = git(root, "rev-parse", "HEAD").stdout.decode().strip()
    if head != RATIFIED_BASE_COMMIT:
        raise GateError(f"candidate preparation requires the exact ratified base HEAD, found {head}")
    tree = git(root, "rev-parse", "HEAD^{tree}").stdout.decode().strip()
    if tree != RATIFIED_BASE_TREE:
        raise GateError(f"candidate preparation requires the exact ratified base tree, found {tree}")
    raw = git(root, "status", "--porcelain=v1", "-z", "--untracked-files=all").stdout
    observed: dict[str, str] = {}
    fields = raw.split(b"\0")
    index = 0
    while index < len(fields):
        field = fields[index]
        index += 1
        if not field:
            continue
        status = field[:2].decode("ascii", "replace")
        path = field[3:].decode("utf-8", "surrogateescape")
        if "R" in status or "C" in status:
            raise GateError(f"candidate diff may not contain renames or copies: {path}")
        if status == "??":
            action = "add"
        elif "D" in status:
            action = "delete"
        elif "A" in status:
            action = "add"
        elif "M" in status:
            action = "modify"
        else:
            raise GateError(f"candidate diff contains an unsupported porcelain status {status!r}: {path}")
        if path in observed:
            raise GateError(f"candidate diff reports duplicate status for: {path}")
        observed[path] = action
    missing = sorted(CANDIDATE_ALLOWLIST_ACTIONS.keys() - observed.keys())
    extra = sorted(observed.keys() - CANDIDATE_ALLOWLIST_ACTIONS.keys())
    if missing:
        raise GateError(f"candidate diff is missing ratified allowlist paths: {', '.join(missing)}")
    if extra:
        raise GateError(f"candidate diff contains paths outside the ratified allowlist: {', '.join(extra)}")
    for path, expected_action in sorted(CANDIDATE_ALLOWLIST_ACTIONS.items()):
        if observed[path] != expected_action:
            raise GateError(
                f"candidate diff action differs from the ratified allowlist: {path} "
                f"is {observed[path]}, ratified as {expected_action}"
            )
    record = portable_amendment_record(root, policy)
    entries = {entry["path"]: entry for entry in record["candidate_manifest"]}
    for path, action in sorted(CANDIDATE_ALLOWLIST_ACTIONS.items()):
        target = root / path
        if action == "delete":
            if target.is_symlink() or target.exists():
                raise GateError(f"ratified delete is still present in the candidate tree: {path}")
            continue
        if path == PORTABLE_AMENDMENT_PATH:
            if target.is_symlink() or not target.is_file():
                raise GateError("the amendment record itself must be a regular candidate file")
            continue
        entry = entries[path]
        snapshot = open_bound_authority_snapshot(root, path)
        try:
            data = finish_bound_authority_read(snapshot)
        finally:
            close_bound_authority_snapshot(snapshot)
        observed_mode = "100755" if snapshot.metadata.st_mode & 0o111 else "100644"
        if observed_mode != entry["mode"] or sha256_bytes(data) != entry["sha256"]:
            raise GateError(f"candidate payload differs from its ratified manifest binding: {path}")
    return {
        "head": head,
        "tree": tree,
        "changed_paths": sorted(observed),
        "counts": {
            kind: sum(1 for value in observed.values() if value == kind)
            for kind in ("add", "modify", "delete")
        },
    }


def architecture_catalogue(root: Path, policy: dict[str, Any]) -> dict[str, Any]:
    catalogue = load_object(root / ARCHITECTURE_CATALOGUE_PATH)
    strict_keys(
        catalogue,
        {"schema", "blueprint_sha256", "slices", "migration_hazards"},
        set(),
        "architecture catalogue",
    )
    if catalogue["schema"] != "giga-v2.architecture-catalogue.v1":
        raise GateError("architecture catalogue schema is invalid")
    expected_blueprint = policy["architecture_target"]["slice_catalogue"]["source_sha256"]
    if catalogue["blueprint_sha256"] != expected_blueprint:
        raise GateError("architecture catalogue has a stale blueprint binding")
    slices = catalogue["slices"]
    expected_ids = {f"JSR-{index:03d}" for index in range(1, 109)}
    if not isinstance(slices, dict) or set(slices) != expected_ids:
        raise GateError("architecture catalogue must contain JSR-001 through JSR-108 exactly")
    for slice_id, title in slices.items():
        nonempty_text(title, f"architecture catalogue {slice_id}.title", minimum=10)
    expected_hazards = {
        "H1": "incomplete quarantine",
        "H2": "mechanical major change",
        "H3": "runtime/deployment drift",
        "H4": "route-class gaps",
        "H5": "stateful-store upgrade",
        "H6": "transitional weak state",
        "H7": "stacked work",
        "H8": "living-doc drift",
    }
    if catalogue["migration_hazards"] != expected_hazards:
        raise GateError("architecture catalogue migration-hazard meanings are stale")
    return catalogue


def lane_registry(root: Path) -> dict[str, dict[str, Any]]:
    value = load_object(root / "control/lanes.json")
    strict_keys(value, {"schema", "lanes"}, set(), "lane registry")
    if value["schema"] != LANE_SCHEMA or not isinstance(value["lanes"], list):
        raise GateError("lane registry schema is invalid")
    result: dict[str, dict[str, Any]] = {}
    all_scopes: list[tuple[str, str]] = []
    for index, lane in enumerate(value["lanes"]):
        if not isinstance(lane, dict):
            raise GateError(f"lane {index} must be an object")
        strict_keys(lane, {"id", "title", "brief", "purpose", "write_scopes"}, set(), f"lane {index}")
        lane_id = lane["id"]
        if not isinstance(lane_id, str) or not ID_PATTERN.fullmatch(lane_id) or lane_id in result:
            raise GateError(f"lane {index} has invalid or duplicate id")
        brief = normal_relative(lane["brief"], f"lane {lane_id}.brief")
        if not (root / brief).is_file():
            raise GateError(f"lane {lane_id} brief does not exist: {brief}")
        scopes = lane["write_scopes"]
        if not isinstance(scopes, list) or not scopes:
            raise GateError(f"lane {lane_id} requires at least one write scope")
        normalized: list[str] = []
        for scope in scopes:
            item = normal_relative(scope, f"lane {lane_id}.write_scopes")
            normalized.append(item)
            all_scopes.append((lane_id, item.rstrip("/") + "/"))
        result[lane_id] = {**lane, "brief": brief, "write_scopes": normalized}
    for i, (left_id, left) in enumerate(all_scopes):
        for right_id, right in all_scopes[i + 1 :]:
            if left_id != right_id and (left.startswith(right) or right.startswith(left)):
                raise GateError(f"lane scopes overlap: {left_id}:{left} and {right_id}:{right}")
    return result


def protected_paths(root: Path) -> list[str]:
    value = load_object(root / "control/protected-paths.json")
    strict_keys(value, {"schema", "paths"}, set(), "protected paths")
    if value["schema"] != "giga-v2.protected-paths.v1" or not isinstance(value["paths"], list):
        raise GateError("protected-path registry schema is invalid")
    declared = [normal_relative(item, "protected path") for item in value["paths"]]
    if tuple(declared) != RATIFIED_PROTECTED_PATHS:
        raise GateError("protected-path registry differs from the judge-bound ratified set")
    return list(RATIFIED_PROTECTED_PATHS)


def path_matches(path: str, prefix: str) -> bool:
    prefix = prefix.rstrip("/")
    return path == prefix or path.startswith(prefix + "/")


def check_foundation(root: Path) -> dict[str, Any]:
    required = [
        "AGENTS.md",
        "README.md",
        "CONSTITUTION.md",
        "control/constitution.lock.json",
        ARCHITECTURE_CATALOGUE_PATH,
        "control/lanes.json",
        "control/protected-paths.json",
        "docs/OPERATING_MANUAL.md",
        "contracts/constitution/DEVELOPMENT_STEWARDSHIP.md",
        STEWARDSHIP_POLICY_PATH,
        ".githooks/pre-commit",
    ]
    missing = [path for path in required if not (root / path).is_file()]
    if missing:
        raise GateError(f"foundation files missing: {', '.join(missing)}")
    identity = constitution_identity(root)
    lock = load_object(root / "control/constitution.lock.json")
    strict_keys(lock, {"schema", "version", "sha256"}, set(), "constitution lock")
    if lock["schema"] != LOCK_SCHEMA or {"version": lock["version"], "sha256": lock["sha256"]} != identity:
        raise GateError("Constitution lock does not match canonical bytes")
    lanes = lane_registry(root)
    protected = protected_paths(root)
    policy = stewardship_policy(root)
    architecture_catalogue(root, policy)
    portable_amendment_record(root, policy)
    return {
        "status": "PASS",
        "constitution": identity,
        "lanes": len(lanes),
        "protected_paths": len(protected),
        "development_stewardship": {
            "status": "PASS",
            "version": policy["version"],
            "policy_sha256": policy["policy_sha256"],
            "work_order_schema": policy["work_order_schema"],
        },
    }


def validate_work_order(order: dict[str, Any], root: Path, *, now: dt.datetime | None = None) -> dict[str, Any]:
    required = {
        "schema",
        "id",
        "lane",
        "created_at",
        "expires_at",
        "max_runtime_seconds",
        "constitution",
        "slice",
        "non_goals",
        "allowed_paths",
        "authority",
        "reuse",
        "decision_rationale",
        "assumptions",
        "unknowns",
        "ai_controls",
        "migration_hazards",
        "acceptance",
        "rollback",
        "next_step",
    }
    strict_keys(order, required, {"operator_time_override"}, "work order")
    if order["schema"] != WORK_ORDER_SCHEMA:
        raise GateError("work order schema is invalid")
    if not isinstance(order["id"], str) or not ID_PATTERN.fullmatch(order["id"]):
        raise GateError("work order id is invalid")
    lanes = lane_registry(root)
    lane = lanes.get(order["lane"])
    if lane is None:
        raise GateError("work order names an unknown lane")
    if order["constitution"] != constitution_identity(root):
        raise GateError("work order Constitution binding is stale or invalid")
    created = parse_timestamp(order["created_at"], "created_at")
    expires = parse_timestamp(order["expires_at"], "expires_at")
    runtime = order["max_runtime_seconds"]
    if not isinstance(runtime, int) or isinstance(runtime, bool) or not 1 <= runtime <= MAX_RUNTIME_SECONDS:
        raise GateError("max_runtime_seconds must be between 1 and 86400")
    if expires <= created or (expires - created).total_seconds() > MAX_RUNTIME_SECONDS:
        raise GateError("work-order authority may span at most 24 hours")
    current = now or utc_now()
    if current >= expires:
        raise GateError("work order has expired")
    policy = stewardship_policy(root)
    stewardship = policy["stewardship"]
    if runtime > stewardship["hard_max_runtime_seconds"]:
        raise GateError("work order exceeds the stewardship runtime ceiling")
    if runtime > stewardship["default_unattended_runtime_seconds"]:
        nonempty_text(order.get("operator_time_override"), "operator_time_override", minimum=30)

    target = policy["architecture_target"]

    def range_values(name: str) -> tuple[str, int, int]:
        value = target[name]
        if not isinstance(value, dict):
            raise GateError(f"architecture_target.{name} must be an object")
        strict_keys(value, {"prefix", "minimum", "maximum"}, set(), f"architecture_target.{name}")
        return value["prefix"], value["minimum"], value["maximum"]

    requirement_prefix, requirement_min, requirement_max = range_values("requirement_range")
    law_prefix, law_min, law_max = range_values("law_range")
    layer_prefix, layer_min, layer_max = range_values("layer_range")
    catalogue_range = target["slice_catalogue"]
    if not isinstance(catalogue_range, dict):
        raise GateError("architecture_target.slice_catalogue must be an object")
    strict_keys(catalogue_range, {"prefix", "minimum", "maximum", "source_sha256"}, set(), "slice_catalogue")
    catalogue_contract = architecture_catalogue(root, policy)

    slice_record = order["slice"]
    if not isinstance(slice_record, dict):
        raise GateError("slice must be an object")
    strict_keys(
        slice_record,
        {
            "id",
            "title",
            "outcome_class",
            "objective",
            "present_problem",
            "present_evidence",
            "operator_requirements",
            "architectural_laws",
            "layers",
            "target_source_hashes",
            "why_needed",
            "smallest_useful_outcome",
            "abandonment_safety",
            "prerequisites",
            "current_owner",
        },
        set(),
        "slice",
    )
    slice_id = valid_numbered_id(
        slice_record["id"],
        catalogue_range["prefix"],
        catalogue_range["minimum"],
        catalogue_range["maximum"],
        "slice.id",
    )
    if slice_record["title"] != catalogue_contract["slices"][slice_id]:
        raise GateError("slice.title does not match the ratified JSR catalogue")
    for field in (
        "objective",
        "present_problem",
        "why_needed",
        "smallest_useful_outcome",
        "abandonment_safety",
        "current_owner",
    ):
        nonempty_text(slice_record[field], f"slice.{field}", minimum=30)
    if slice_record["outcome_class"] not in OUTCOME_CLASSES:
        raise GateError("slice.outcome_class is not an allowed reuse outcome")
    nonempty_text_list(slice_record["present_evidence"], "slice.present_evidence")
    nonempty_text_list(slice_record["prerequisites"], "slice.prerequisites")

    def validate_architecture_ids(values: Any, prefix: str, minimum: int, maximum: int, location: str) -> list[str]:
        if not isinstance(values, list) or not values:
            raise GateError(f"{location} must contain at least one identifier")
        checked = [valid_numbered_id(item, prefix, minimum, maximum, f"{location}[{index}]") for index, item in enumerate(values)]
        if len(checked) != len(set(checked)):
            raise GateError(f"{location} contains duplicates")
        return checked

    requirement_ids = validate_architecture_ids(
        slice_record["operator_requirements"], requirement_prefix, requirement_min, requirement_max, "slice.operator_requirements"
    )
    validate_architecture_ids(slice_record["architectural_laws"], law_prefix, law_min, law_max, "slice.architectural_laws")
    validate_architecture_ids(slice_record["layers"], layer_prefix, layer_min, layer_max, "slice.layers")
    expected_target_hashes = {source["sha256"] for source in target["sources"]}
    if set(slice_record["target_source_hashes"]) != expected_target_hashes or len(slice_record["target_source_hashes"]) != 2:
        raise GateError("slice.target_source_hashes must bind both ratified architecture sources exactly")

    non_goals = nonempty_text_list(order["non_goals"], "non_goals")
    allowed = order["allowed_paths"]
    if not isinstance(allowed, list) or not allowed:
        raise GateError("allowed_paths must contain at least one path")
    normalized = [normal_relative(item, "allowed_paths") for item in allowed]
    for item in normalized:
        if not any(path_matches(item.rstrip("/"), scope) for scope in lane["write_scopes"]):
            raise GateError(f"path is outside lane ownership: {item}")
        if any(path_matches(item.rstrip("/"), protected) or path_matches(protected, item) for protected in protected_paths(root)):
            raise GateError(f"path intersects protected policy: {item}")
    authority = order["authority"]
    if not isinstance(authority, dict):
        raise GateError("authority must be an object")
    strict_keys(authority, {"vault_access", "external_writes", "irreversible_actions"}, set(), "authority")
    if any(authority.get(name) is not False for name in authority):
        raise GateError("foundation development work orders deny Vault, external-write and irreversible authority")
    reuse = order["reuse"]
    if not isinstance(reuse, dict):
        raise GateError("reuse must be an object")
    strict_keys(reuse, {"searched", "closest_candidates", "decision"}, set(), "reuse")
    nonempty_text_list(reuse["searched"], "reuse.searched")
    nonempty_text_list(reuse["closest_candidates"], "reuse.closest_candidates")
    nonempty_text(reuse["decision"], "reuse.decision", minimum=30)
    if not reuse["decision"].lstrip().startswith(slice_record["outcome_class"]):
        raise GateError("reuse.decision must begin with slice.outcome_class")

    rationale = order["decision_rationale"]
    if not isinstance(rationale, list) or not rationale:
        raise GateError("decision_rationale must contain at least one explanation")
    for index, item in enumerate(rationale):
        if not isinstance(item, dict):
            raise GateError(f"decision_rationale {index} must be an object")
        strict_keys(item, {"decision", "needed_because", "operator_requirement"}, set(), f"decision_rationale {index}")
        nonempty_text(item["decision"], f"decision_rationale {index}.decision", minimum=20)
        nonempty_text(item["needed_because"], f"decision_rationale {index}.needed_because", minimum=30)
        if item["operator_requirement"] not in requirement_ids:
            raise GateError(f"decision_rationale {index} cites a requirement not selected by this slice")
    nonempty_text_list(order["assumptions"], "assumptions")
    nonempty_text_list(order["unknowns"], "unknowns")

    acceptance = order["acceptance"]
    if not isinstance(acceptance, list) or not acceptance:
        raise GateError("acceptance must contain at least one proof")
    proof_ids: set[str] = set()
    proof_categories: dict[str, str] = {}
    for index, proof in enumerate(acceptance):
        if not isinstance(proof, dict):
            raise GateError(f"acceptance {index} must be an object")
        strict_keys(
            proof,
            {"id", "category", "proves", "argv", "cwd", "expected_exit_code", "timeout_seconds"},
            set(),
            f"acceptance {index}",
        )
        proof_id = proof["id"]
        if not isinstance(proof_id, str) or not ID_PATTERN.fullmatch(proof_id) or proof_id in proof_ids:
            raise GateError(f"acceptance {index} has invalid or duplicate id")
        proof_ids.add(proof_id)
        if proof["category"] not in PROOF_CATEGORIES:
            raise GateError(f"acceptance {proof_id}.category is invalid")
        proof_categories[proof_id] = proof["category"]
        nonempty_text(proof["proves"], f"acceptance {proof_id}.proves", minimum=30)
        if not isinstance(proof["argv"], list) or not proof["argv"] or not all(isinstance(x, str) and x for x in proof["argv"]):
            raise GateError(f"acceptance {proof_id}.argv must be direct non-empty arguments")
        executable = Path(proof["argv"][0]).name
        if executable in {"true", "echo", "printf"}:
            raise GateError(f"acceptance {proof_id}.argv is an obvious no-op proof")
        if len(proof["argv"]) >= 2 and proof["argv"][1] == "-c" and executable in {
            "bash",
            "dash",
            "fish",
            "python",
            "python3",
            "sh",
            "zsh",
        }:
            raise GateError(f"acceptance {proof_id}.argv may not use inline interpreter code")
        normal_relative(proof["cwd"], f"acceptance {proof_id}.cwd", allow_dot=True)
        if not isinstance(proof["expected_exit_code"], int) or isinstance(proof["expected_exit_code"], bool):
            raise GateError(f"acceptance {proof_id}.expected_exit_code must be an integer")
        timeout = proof["timeout_seconds"]
        if not isinstance(timeout, int) or isinstance(timeout, bool) or not 1 <= timeout <= 3600:
            raise GateError(f"acceptance {proof_id}.timeout_seconds must be 1..3600")
    categories = {proof["category"] for proof in acceptance}
    if "focused-positive" not in categories or "negative" not in categories or not categories.intersection({"regression", "system"}):
        raise GateError("acceptance requires focused-positive, negative and regression/system proofs")

    ai_controls = order["ai_controls"]
    if not isinstance(ai_controls, dict):
        raise GateError("ai_controls must be an object")
    strict_keys(ai_controls, set(policy["ai_control_fields"]), set(), "ai_controls")
    hallucination = ai_controls["hallucination"]
    if not isinstance(hallucination, dict):
        raise GateError("ai_controls.hallucination must be an object")
    strict_keys(hallucination, {"claims_require", "inspected_sources", "falsifier"}, set(), "ai_controls.hallucination")
    nonempty_text_list(hallucination["claims_require"], "ai_controls.hallucination.claims_require")
    nonempty_text_list(hallucination["inspected_sources"], "ai_controls.hallucination.inspected_sources")
    nonempty_text(hallucination["falsifier"], "ai_controls.hallucination.falsifier", minimum=30)

    scope_drift = ai_controls["scope_drift"]
    if not isinstance(scope_drift, dict):
        raise GateError("ai_controls.scope_drift must be an object")
    strict_keys(scope_drift, {"excluded_work", "stop_when"}, set(), "ai_controls.scope_drift")
    excluded_work = nonempty_text_list(scope_drift["excluded_work"], "ai_controls.scope_drift.excluded_work")
    nonempty_text_list(scope_drift["stop_when"], "ai_controls.scope_drift.stop_when")
    if set(excluded_work) != set(non_goals):
        raise GateError("scope_drift.excluded_work must exactly match non_goals")

    context_bloat = ai_controls["context_bloat"]
    if not isinstance(context_bloat, dict):
        raise GateError("ai_controls.context_bloat must be an object")
    strict_keys(
        context_bloat,
        {"required_sources", "excluded_sources", "nuance_anchors", "max_source_files"},
        set(),
        "ai_controls.context_bloat",
    )
    required_sources = nonempty_text_list(context_bloat["required_sources"], "ai_controls.context_bloat.required_sources")
    nonempty_text_list(context_bloat["excluded_sources"], "ai_controls.context_bloat.excluded_sources")
    nuance_anchors = nonempty_text_list(context_bloat["nuance_anchors"], "ai_controls.context_bloat.nuance_anchors")
    ceiling = context_bloat["max_source_files"]
    if not isinstance(ceiling, int) or isinstance(ceiling, bool) or not len(required_sources) <= ceiling <= 50:
        raise GateError("context_bloat.max_source_files must cover required_sources and be at most 50")
    for identifier in (*requirement_ids, *slice_record["architectural_laws"], *slice_record["layers"]):
        if not any(mentions_identifier(anchor, identifier) for anchor in nuance_anchors):
            raise GateError(f"context_bloat.nuance_anchors omit selected identifier: {identifier}")

    tunnel_vision = ai_controls["tunnel_vision"]
    if not isinstance(tunnel_vision, dict):
        raise GateError("ai_controls.tunnel_vision must be an object")
    strict_keys(tunnel_vision, {"counterevidence", "stop_or_change_if"}, set(), "ai_controls.tunnel_vision")
    nonempty_text(tunnel_vision["counterevidence"], "ai_controls.tunnel_vision.counterevidence", minimum=30)
    nonempty_text(tunnel_vision["stop_or_change_if"], "ai_controls.tunnel_vision.stop_or_change_if", minimum=30)

    failure_forecast = ai_controls["failure_forecast"]
    if not isinstance(failure_forecast, list) or not failure_forecast:
        raise GateError("ai_controls.failure_forecast must contain at least one failure")
    for index, failure in enumerate(failure_forecast):
        if not isinstance(failure, dict):
            raise GateError(f"failure_forecast {index} must be an object")
        strict_keys(failure, {"failure", "safe_state", "proof_id"}, set(), f"failure_forecast {index}")
        nonempty_text(failure["failure"], f"failure_forecast {index}.failure", minimum=20)
        nonempty_text(failure["safe_state"], f"failure_forecast {index}.safe_state", minimum=30)
        if failure["proof_id"] not in proof_ids:
            raise GateError(f"failure_forecast {index} cites an unknown proof")
        if proof_categories[failure["proof_id"]] not in {"negative", "rollback", "system"}:
            raise GateError(f"failure_forecast {index} must cite a negative, rollback or system proof")

    sanity = ai_controls["sanity_check"]
    if not isinstance(sanity, dict):
        raise GateError("ai_controls.sanity_check must be an object")
    strict_keys(sanity, {"claim", "falsifier", "proof_ids"}, set(), "ai_controls.sanity_check")
    nonempty_text(sanity["claim"], "ai_controls.sanity_check.claim", minimum=30)
    nonempty_text(sanity["falsifier"], "ai_controls.sanity_check.falsifier", minimum=30)
    sanity_proofs = _string_ids(sanity["proof_ids"], "ai_controls.sanity_check.proof_ids")
    if not set(sanity_proofs) <= proof_ids:
        raise GateError("sanity_check cites an unknown proof")
    sanity_categories = {proof_categories[proof_id] for proof_id in sanity_proofs}
    if "focused-positive" not in sanity_categories or "negative" not in sanity_categories:
        raise GateError("sanity_check must cite both focused-positive and negative proof categories")

    hazards = order["migration_hazards"]
    if not isinstance(hazards, dict):
        raise GateError("migration_hazards must be an object")
    strict_keys(hazards, {f"H{index}" for index in range(1, 9)}, set(), "migration_hazards")
    expected_hazard_names = catalogue_contract["migration_hazards"]
    for key, value in hazards.items():
        nonempty_text(value, f"migration_hazards.{key}", minimum=20)
        if not value.lower().startswith(expected_hazard_names[key] + ":"):
            raise GateError(f"migration_hazards.{key} must preserve its canonical hazard meaning")

    rollback = order["rollback"]
    if not isinstance(rollback, dict):
        raise GateError("rollback must be a structured object")
    strict_keys(rollback, {"strategy", "steps", "preserves", "verification_proof_ids"}, set(), "rollback")
    if rollback["strategy"] not in {"git-revert-candidate", "restore-checkpoint", "compensating-action", "not-applicable"}:
        raise GateError("rollback.strategy is invalid")
    nonempty_text_list(rollback["steps"], "rollback.steps")
    nonempty_text(rollback["preserves"], "rollback.preserves", minimum=30)
    rollback_proofs = _string_ids(rollback["verification_proof_ids"], "rollback.verification_proof_ids")
    if not set(rollback_proofs) <= proof_ids:
        raise GateError("rollback cites an unknown proof")
    if not {proof_categories[proof_id] for proof_id in rollback_proofs}.intersection({"rollback", "regression", "system"}):
        raise GateError("rollback must cite a rollback, regression or system proof")
    next_step = order["next_step"]
    if not isinstance(next_step, dict):
        raise GateError("next_step must be an object")
    strict_keys(next_step, {"propose_only", "successor_authorized"}, set(), "next_step")
    if next_step != {"propose_only": True, "successor_authorized": False}:
        raise GateError("next_step must propose only and deny automatic successor authority")
    return {**order, "allowed_paths": normalized, "lane_record": lane}


def git(root: Path, *arguments: str, check: bool = True) -> subprocess.CompletedProcess[bytes]:
    environment = {
        **os.environ,
        "GIT_CONFIG_NOSYSTEM": "1",
        "GIT_CONFIG_GLOBAL": "/dev/null",
        "GIT_CONFIG_SYSTEM": "/dev/null",
    }
    result = subprocess.run(
        ["git", "-C", str(root), *arguments],
        stdout=subprocess.PIPE,
        stderr=subprocess.PIPE,
        check=False,
        env=environment,
    )
    if check and result.returncode:
        raise GateError(f"git {' '.join(arguments)} failed: {result.stderr.decode(errors='replace').strip()}")
    return result


def git_identity(root: Path) -> dict[str, Any]:
    return {
        "root": str(root.resolve()),
        "branch": git(root, "branch", "--show-current").stdout.decode().strip(),
        "commit": git(root, "rev-parse", "HEAD").stdout.decode().strip(),
        "status_sha256": sha256_bytes(git(root, "status", "--porcelain=v1", "-z", "--untracked-files=all").stdout),
    }


def changed_paths(root: Path, starting_commit: str) -> list[str]:
    names: set[str] = set()
    committed = git(root, "diff", "--name-only", "-z", f"{starting_commit}..HEAD", "--").stdout
    unstaged = git(root, "diff", "--name-only", "-z", "HEAD", "--").stdout
    staged = git(root, "diff", "--cached", "--name-only", "-z", "HEAD", "--").stdout
    untracked = git(root, "ls-files", "--others", "--exclude-standard", "-z").stdout
    for value in (committed + unstaged + staged + untracked).split(b"\0"):
        if value:
            names.add(value.decode("utf-8", "surrogateescape"))
    return sorted(names)


def gate_owned(path: str, order_id: str, work_order_path: str) -> bool:
    return path == work_order_path or path_matches(path, f"receipts/{order_id}/")


def payload_paths(paths: Iterable[str], order_id: str) -> list[str]:
    return sorted(path for path in paths if not path_matches(path, f"receipts/{order_id}/"))


def worktree_payload_manifest(root: Path, paths: Iterable[str]) -> list[dict[str, Any]]:
    manifest: list[dict[str, Any]] = []
    for relative in sorted(set(paths)):
        path = root / relative
        if path.is_symlink():
            manifest.append(
                {"path": relative, "type": "symlink", "sha256": sha256_bytes(os.readlink(path).encode())}
            )
        elif path.is_file():
            manifest.append({"path": relative, "type": "file", "sha256": digest(path)})
        elif not path.exists():
            manifest.append({"path": relative, "type": "deleted", "sha256": None})
        else:
            raise GateError(f"candidate payload path is not a file, symlink or deletion: {relative}")
    return manifest


def commit_payload_manifest(root: Path, commit: str, paths: Iterable[str]) -> list[dict[str, Any]]:
    manifest: list[dict[str, Any]] = []
    for relative in sorted(set(paths)):
        entry = git(root, "ls-tree", commit, "--", relative).stdout.decode().strip()
        if not entry:
            manifest.append({"path": relative, "type": "deleted", "sha256": None})
            continue
        metadata, listed_path = entry.split("\t", 1)
        if listed_path != relative:
            raise GateError(f"candidate commit returned an unexpected path: {listed_path}")
        mode, kind, object_id = metadata.split()
        if kind != "blob":
            raise GateError(f"candidate commit path is not a blob: {relative}")
        data = git(root, "cat-file", "blob", object_id).stdout
        manifest.append(
            {
                "path": relative,
                "type": "symlink" if mode == "120000" else "file",
                "sha256": sha256_bytes(data),
            }
        )
    return manifest


def reject_paths(paths: Iterable[str], order: dict[str, Any], root: Path, work_order_path: str) -> list[str]:
    rejected: list[str] = []
    for path in paths:
        if gate_owned(path, order["id"], work_order_path):
            continue
        if any(path_matches(path, protected) for protected in protected_paths(root)):
            rejected.append(path)
            continue
        if not any(path_matches(path, allowed) for allowed in order["allowed_paths"]):
            rejected.append(path)
    return sorted(set(rejected))


def scan_secrets(root: Path, paths: Iterable[str]) -> list[str]:
    findings: list[str] = []
    for relative in paths:
        path = root / relative
        if not path.is_file() or path.is_symlink() or path.stat().st_size > 4 * 1024 * 1024:
            continue
        data = path.read_bytes()
        if any(pattern.search(data) for pattern in SECRET_PATTERNS):
            findings.append(relative)
    return findings


def relative_to_root(path: Path, root: Path) -> str:
    try:
        return path.resolve().relative_to(root.resolve()).as_posix()
    except ValueError as exc:
        raise GateError(f"path is outside project root: {path}") from exc


def admit(root: Path, work_order_path: Path) -> Path:
    check_foundation(root)
    order = validate_work_order(load_object(work_order_path), root)
    relative_order = relative_to_root(work_order_path, root)
    receipt = self_bound(
        {
            "schema": PREFLIGHT_SCHEMA,
            "status": "PASS",
            "recorded_at": timestamp(),
            "work_order_id": order["id"],
            "work_order_path": relative_order,
            "work_order_sha256": digest(work_order_path),
            "constitution": constitution_identity(root),
            "lane": order["lane"],
            "allowed_paths": order["allowed_paths"],
            "expires_at": order["expires_at"],
            "starting_state": git_identity(root),
        }
    )
    output = root / "receipts" / order["id"] / "preflight.json"
    write_object(output, receipt)
    return output


def run_proof(root: Path, proof: dict[str, Any]) -> dict[str, Any]:
    cwd = root.resolve() if proof["cwd"] == "." else (root / proof["cwd"]).resolve()
    try:
        cwd.relative_to(root.resolve())
    except ValueError as exc:
        raise GateError(f"acceptance cwd escaped project: {proof['cwd']}") from exc
    try:
        result = subprocess.run(
            proof["argv"],
            cwd=cwd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            timeout=proof["timeout_seconds"],
            check=False,
        )
        actual = result.returncode
        stdout = result.stdout
        stderr = result.stderr
        timed_out = False
    except subprocess.TimeoutExpired as exc:
        actual = None
        stdout = exc.stdout or b""
        stderr = exc.stderr or b""
        timed_out = True
    return {
        "id": proof["id"],
        "category": proof["category"],
        "proves": proof["proves"],
        "argv": proof["argv"],
        "cwd": proof["cwd"],
        "expected_exit_code": proof["expected_exit_code"],
        "actual_exit_code": actual,
        "timed_out": timed_out,
        "passed": not timed_out and actual == proof["expected_exit_code"],
        "stdout_sha256": sha256_bytes(stdout),
        "stderr_sha256": sha256_bytes(stderr),
        "stdout_tail": stdout.decode(errors="replace")[-2000:],
        "stderr_tail": stderr.decode(errors="replace")[-2000:],
    }


def verify(root: Path, work_order_path: Path, preflight_path: Path) -> tuple[Path, bool]:
    check_foundation(root)
    order_raw = load_object(work_order_path)
    order = validate_work_order(order_raw, root)
    preflight = load_object(preflight_path)
    if preflight.get("schema") != PREFLIGHT_SCHEMA or not valid_self_hash(preflight):
        raise GateError("preflight receipt is invalid")
    if preflight.get("status") != "PASS" or preflight.get("work_order_id") != order["id"]:
        raise GateError("preflight receipt does not admit this work order")
    if preflight.get("work_order_sha256") != digest(work_order_path):
        raise GateError("work order changed after admission")
    if preflight.get("constitution") != constitution_identity(root):
        raise GateError("Constitution changed after admission")
    start = preflight.get("starting_state")
    if not isinstance(start, dict) or not isinstance(start.get("commit"), str):
        raise GateError("preflight starting state is invalid")
    relative_order = relative_to_root(work_order_path, root)
    paths = changed_paths(root, start["commit"])
    rejected = reject_paths(paths, order, root, relative_order)
    secrets = scan_secrets(root, [path for path in paths if not gate_owned(path, order["id"], relative_order)])
    proofs = [run_proof(root, proof) for proof in order["acceptance"]]
    passed = not rejected and not secrets and all(proof["passed"] for proof in proofs)
    candidate_payload = worktree_payload_manifest(root, payload_paths(paths, order["id"]))
    receipt = self_bound(
        {
            "schema": COMPLETION_SCHEMA,
            "status": "PASS" if passed else "REJECT",
            "recorded_at": timestamp(),
            "work_order_id": order["id"],
            "work_order_sha256": digest(work_order_path),
            "preflight_sha256": preflight["receipt_sha256"],
            "constitution": constitution_identity(root),
            "lane": order["lane"],
            "starting_commit": start["commit"],
            "observed_head": git(root, "rev-parse", "HEAD").stdout.decode().strip(),
            "changed_paths": paths,
            "candidate_payload": candidate_payload,
            "candidate_payload_sha256": sha256_bytes(canonical(candidate_payload)),
            "rejected_paths": rejected,
            "secret_findings": secrets,
            "proofs": proofs,
            "rollback": order["rollback"],
        }
    )
    output = root / "receipts" / order["id"] / "completion.json"
    write_object(output, receipt)
    return output, passed


def committed_changed_paths(root: Path, starting_commit: str, candidate_commit: str) -> list[str]:
    values = git(root, "diff", "--name-only", "-z", f"{starting_commit}..{candidate_commit}", "--").stdout
    return sorted(value.decode("utf-8", "surrogateescape") for value in values.split(b"\0") if value)


def commit_file_bytes(root: Path, commit: str, relative: str) -> bytes:
    result = git(root, "show", f"{commit}:{relative}", check=False)
    if result.returncode:
        raise GateError(f"candidate commit does not contain required evidence: {relative}")
    return result.stdout


def validate_candidate_evidence(
    root: Path,
    work_order_path: Path,
    preflight_path: Path,
    completion_path: Path,
    candidate_commit: str,
) -> dict[str, Any]:
    check_foundation(root)
    preflight = load_object(preflight_path)
    completion = load_object(completion_path)
    if preflight.get("schema") != PREFLIGHT_SCHEMA or not valid_self_hash(preflight):
        raise GateError("preflight receipt is invalid")
    if completion.get("schema") != COMPLETION_SCHEMA or not valid_self_hash(completion):
        raise GateError("completion receipt is invalid")
    completion_time = parse_timestamp(completion.get("recorded_at"), "completion.recorded_at")
    order = validate_work_order(load_object(work_order_path), root, now=completion_time)
    relative_order = relative_to_root(work_order_path, root)
    relative_preflight = relative_to_root(preflight_path, root)
    relative_completion = relative_to_root(completion_path, root)
    expected_receipt_root = f"receipts/{order['id']}"
    if relative_order != f"work_orders/{order['id']}.json":
        raise GateError("candidate evidence requires the canonical work-order path")
    if relative_preflight != f"{expected_receipt_root}/preflight.json":
        raise GateError("candidate evidence requires the canonical preflight path")
    if relative_completion != f"{expected_receipt_root}/completion.json":
        raise GateError("candidate evidence requires the canonical completion path")
    if preflight.get("status") != "PASS" or preflight.get("work_order_id") != order["id"]:
        raise GateError("preflight receipt does not admit this work order")
    if preflight.get("work_order_path") != relative_order or preflight.get("work_order_sha256") != digest(work_order_path):
        raise GateError("preflight receipt has a stale work-order binding")
    if preflight.get("constitution") != constitution_identity(root):
        raise GateError("preflight receipt has a stale Constitution binding")
    if preflight.get("lane") != order["lane"] or preflight.get("allowed_paths") != order["allowed_paths"]:
        raise GateError("preflight receipt has a stale authority binding")
    if preflight.get("expires_at") != order["expires_at"]:
        raise GateError("preflight receipt has a stale expiry binding")
    if completion.get("status") != "PASS" or completion.get("work_order_id") != order["id"]:
        raise GateError("completion receipt does not pass this work order")
    if completion.get("work_order_sha256") != digest(work_order_path):
        raise GateError("completion receipt has a stale work-order binding")
    if completion.get("preflight_sha256") != preflight["receipt_sha256"]:
        raise GateError("completion receipt has a stale preflight binding")
    if completion.get("constitution") != constitution_identity(root) or completion.get("lane") != order["lane"]:
        raise GateError("completion receipt has a stale constitutional or lane binding")
    if completion.get("rollback") != order["rollback"]:
        raise GateError("completion receipt has a stale rollback binding")
    if completion.get("rejected_paths") != [] or completion.get("secret_findings") != []:
        raise GateError("completion receipt records rejected paths or secret findings")
    start = preflight.get("starting_state")
    if not isinstance(start, dict) or not isinstance(start.get("commit"), str):
        raise GateError("preflight starting state is invalid")
    starting_commit = start["commit"]
    if completion.get("starting_commit") != starting_commit:
        raise GateError("completion receipt has a stale starting-commit binding")
    resolved_candidate = git(root, "rev-parse", f"{candidate_commit}^{{commit}}").stdout.decode().strip()
    if resolved_candidate == starting_commit:
        raise GateError("candidate attestation requires a commit after the admitted starting state")
    ancestor = git(root, "merge-base", "--is-ancestor", starting_commit, resolved_candidate, check=False)
    if ancestor.returncode != 0:
        raise GateError("candidate commit is not descended from the admitted starting state")
    current_head = git(root, "rev-parse", "HEAD").stdout.decode().strip()
    if current_head != resolved_candidate:
        raise GateError("candidate evidence must be checked from the exact candidate HEAD")
    allowed_uncommitted = {f"receipts/{order['id']}/attestation.json"}
    uncommitted = set(changed_paths(root, resolved_candidate))
    if not uncommitted <= allowed_uncommitted:
        raise GateError("candidate worktree contains uncommitted state outside its attestation")

    if sha256_bytes(commit_file_bytes(root, resolved_candidate, relative_order)) != digest(work_order_path):
        raise GateError("candidate commit work order differs from the admitted work order")
    if sha256_bytes(commit_file_bytes(root, resolved_candidate, relative_preflight)) != digest(preflight_path):
        raise GateError("candidate commit preflight receipt differs from the admitted receipt")
    if sha256_bytes(commit_file_bytes(root, resolved_candidate, relative_completion)) != digest(completion_path):
        raise GateError("candidate commit completion receipt differs from the verified receipt")

    committed_paths = committed_changed_paths(root, starting_commit, resolved_candidate)
    if reject_paths(committed_paths, order, root, relative_order):
        raise GateError("candidate commit contains paths outside admitted scope")
    committed_payload_paths = payload_paths(committed_paths, order["id"])
    recorded_changed_paths = completion.get("changed_paths")
    if not isinstance(recorded_changed_paths, list) or payload_paths(recorded_changed_paths, order["id"]) != committed_payload_paths:
        raise GateError("completion receipt payload path set differs from the candidate commit")
    recorded_payload = completion.get("candidate_payload")
    if not isinstance(recorded_payload, list):
        raise GateError("completion receipt has no candidate payload manifest")
    if [item.get("path") for item in recorded_payload if isinstance(item, dict)] != committed_payload_paths:
        raise GateError("candidate commit path set differs from the verified payload")
    committed_payload = commit_payload_manifest(root, resolved_candidate, committed_payload_paths)
    if committed_payload != recorded_payload:
        raise GateError("candidate commit bytes differ from the verified payload")
    payload_hash = sha256_bytes(canonical(committed_payload))
    if completion.get("candidate_payload_sha256") != payload_hash:
        raise GateError("completion receipt payload hash is invalid")

    proofs = completion.get("proofs")
    if not isinstance(proofs, list) or len(proofs) != len(order["acceptance"]):
        raise GateError("completion receipt proof set differs from the work order")
    for expected, observed in zip(order["acceptance"], proofs):
        for field in ("id", "category", "proves", "argv", "cwd", "expected_exit_code"):
            if observed.get(field) != expected[field]:
                raise GateError(f"completion proof {expected['id']} has a stale {field} binding")
        if observed.get("passed") is not True or observed.get("timed_out") is not False:
            raise GateError(f"completion proof {expected['id']} did not pass")
        if observed.get("actual_exit_code") != expected["expected_exit_code"]:
            raise GateError(f"completion proof {expected['id']} exit code is inconsistent")
        rerun = run_proof(root, expected)
        if rerun["passed"] is not True:
            raise GateError(f"candidate proof {expected['id']} failed independent re-execution")

    return {
        "order": order,
        "preflight": preflight,
        "completion": completion,
        "candidate_commit": resolved_candidate,
        "candidate_tree": git(root, "rev-parse", f"{resolved_candidate}^{{tree}}").stdout.decode().strip(),
        "payload_hash": payload_hash,
        "committed_paths": committed_paths,
    }


def attest_candidate(
    root: Path,
    work_order_path: Path,
    preflight_path: Path,
    completion_path: Path,
    candidate_commit: str,
) -> Path:
    evidence = validate_candidate_evidence(root, work_order_path, preflight_path, completion_path, candidate_commit)
    order = evidence["order"]
    preflight = evidence["preflight"]
    completion = evidence["completion"]

    receipt = self_bound(
        {
            "schema": ATTESTATION_SCHEMA,
            "status": "PASS",
            "recorded_at": timestamp(),
            "work_order_id": order["id"],
            "work_order_sha256": digest(work_order_path),
            "preflight_sha256": preflight["receipt_sha256"],
            "completion_sha256": completion["receipt_sha256"],
            "constitution": constitution_identity(root),
            "candidate_commit": evidence["candidate_commit"],
            "candidate_tree": evidence["candidate_tree"],
            "candidate_payload_sha256": evidence["payload_hash"],
            "changed_paths": evidence["committed_paths"],
        }
    )
    output = root / "receipts" / order["id"] / "attestation.json"
    write_object(output, receipt)
    return output


def check_attestation(root: Path, attestation_path: Path) -> dict[str, Any]:
    check_foundation(root)
    value = load_object(attestation_path)
    strict_keys(
        value,
        {
            "schema",
            "status",
            "recorded_at",
            "work_order_id",
            "work_order_sha256",
            "preflight_sha256",
            "completion_sha256",
            "constitution",
            "candidate_commit",
            "candidate_tree",
            "candidate_payload_sha256",
            "changed_paths",
            "receipt_sha256",
        },
        set(),
        "candidate attestation",
    )
    if value.get("schema") != ATTESTATION_SCHEMA or not valid_self_hash(value) or value.get("status") != "PASS":
        raise GateError("candidate attestation is invalid")
    work_order_id = value.get("work_order_id")
    if not isinstance(work_order_id, str) or not ID_PATTERN.fullmatch(work_order_id):
        raise GateError("candidate attestation has an invalid work-order id")
    canonical_attestation = root / "receipts" / work_order_id / "attestation.json"
    if attestation_path.resolve() != canonical_attestation.resolve():
        raise GateError("candidate attestation is not at its canonical path")
    commit = value.get("candidate_commit")
    if not isinstance(commit, str):
        raise GateError("candidate attestation has no commit")
    evidence = validate_candidate_evidence(
        root,
        root / "work_orders" / f"{work_order_id}.json",
        root / "receipts" / work_order_id / "preflight.json",
        root / "receipts" / work_order_id / "completion.json",
        commit,
    )
    expected = {
        "work_order_sha256": digest(root / "work_orders" / f"{work_order_id}.json"),
        "preflight_sha256": evidence["preflight"]["receipt_sha256"],
        "completion_sha256": evidence["completion"]["receipt_sha256"],
        "constitution": constitution_identity(root),
        "candidate_commit": evidence["candidate_commit"],
        "candidate_tree": evidence["candidate_tree"],
        "candidate_payload_sha256": evidence["payload_hash"],
        "changed_paths": evidence["committed_paths"],
    }
    for field, expected_value in expected.items():
        if value.get(field) != expected_value:
            raise GateError(f"candidate attestation has a stale {field} binding")
    return value


def staged_paths(root: Path) -> list[str]:
    values = git(root, "diff", "--cached", "--name-only", "-z", "--").stdout
    return sorted(value.decode("utf-8", "surrogateescape") for value in values.split(b"\0") if value)


def hook(root: Path) -> None:
    check_foundation(root)
    paths = staged_paths(root)
    protected = [path for path in paths if any(path_matches(path, item) for item in protected_paths(root))]
    if protected:
        raise GateError(f"protected constitutional paths cannot be committed by a lane: {', '.join(protected)}")
    work_order_value = os.environ.get("GIGA_WORK_ORDER")
    if not work_order_value:
        raise GateError("GIGA_WORK_ORDER is required for lane commits")
    work_order_path = (root / work_order_value).resolve() if not Path(work_order_value).is_absolute() else Path(work_order_value).resolve()
    order = validate_work_order(load_object(work_order_path), root)
    relative_order = relative_to_root(work_order_path, root)
    rejected = reject_paths(paths, order, root, relative_order)
    if rejected:
        raise GateError(f"staged paths exceed admitted lane scope: {', '.join(rejected)}")
    secrets = scan_secrets(root, paths)
    if secrets:
        raise GateError(f"possible secrets detected in staged files: {', '.join(secrets)}")


def build_template(root: Path, lane_id: str, work_order_id: str) -> dict[str, Any]:
    lanes = lane_registry(root)
    lane = lanes.get(lane_id)
    if lane is None:
        raise GateError(f"unknown lane: {lane_id}")
    now = utc_now().replace(microsecond=0)
    default_scope = lane["write_scopes"][0]
    if lane_id == "constitution-enforcement":
        default_scope = "giga_control/extensions/"
    target_hashes = [source["sha256"] for source in stewardship_policy(root)["architecture_target"]["sources"]]
    non_goals = ["Replace with one explicit adjacent outcome that this slice must not start."]
    return {
        "schema": WORK_ORDER_SCHEMA,
        "id": work_order_id,
        "lane": lane_id,
        "created_at": timestamp(now),
        "expires_at": timestamp(now + dt.timedelta(seconds=DEFAULT_UNATTENDED_SECONDS)),
        "max_runtime_seconds": DEFAULT_UNATTENDED_SECONDS,
        "constitution": constitution_identity(root),
        "slice": {
            "id": "JSR-000",
            "title": "Replace with the exact catalogue slice title.",
            "outcome_class": "BUILD",
            "objective": "Replace with one independently useful end-to-end outcome.",
            "present_problem": "Replace with the current observable problem and affected owner.",
            "present_evidence": ["Replace with an inspected path, receipt, command result or affected-system observation."],
            "operator_requirements": ["R-00"],
            "architectural_laws": ["L-00"],
            "layers": ["L0"],
            "target_source_hashes": target_hashes,
            "why_needed": "Replace with why this decision follows from the cited operator requirement or observed failure.",
            "smallest_useful_outcome": "Replace with the smallest result that becomes useful immediately.",
            "abandonment_safety": "Replace with why stopping after this slice leaves current work valid.",
            "prerequisites": ["Replace with already-verified receipt identifiers or explicit none-with-evidence."],
            "current_owner": "Replace with the canonical truth-domain or component owner.",
        },
        "non_goals": non_goals,
        "allowed_paths": [default_scope],
        "authority": {
            "vault_access": False,
            "external_writes": False,
            "irreversible_actions": False,
        },
        "reuse": {
            "searched": ["Replace with inspected repository and upstream scope."],
            "closest_candidates": ["Replace with closest implementation or explicit absence."],
            "decision": "Replace with ADOPT, CONFIGURE, REPAIR, EXTEND, WRAP or BUILD and reason.",
        },
        "decision_rationale": [
            {
                "decision": "Replace with the architectural or implementation decision.",
                "needed_because": "Replace with the operator requirement or observed failure that makes it necessary.",
                "operator_requirement": "R-00",
            }
        ],
        "assumptions": ["Replace with one falsifiable assumption or explicit evidence-backed absence of assumptions."],
        "unknowns": ["Replace with one bounded unknown or explicit evidence-backed absence of unknowns."],
        "ai_controls": {
            "hallucination": {
                "claims_require": ["Replace with the evidence required before each material capability claim."],
                "inspected_sources": ["Replace with the exact sources inspected for current-state claims."],
                "falsifier": "Replace with evidence that would disprove the central implementation assumption.",
            },
            "scope_drift": {
                "excluded_work": non_goals,
                "stop_when": ["Replace with a concrete early-stop condition."],
            },
            "context_bloat": {
                "required_sources": ["Replace with the minimum canonical source set."],
                "excluded_sources": ["Replace with adjacent sources that must not enter this slice."],
                "nuance_anchors": ["Replace with R-00, L-00 and L0 boundary text that must survive compaction."],
                "max_source_files": 10,
            },
            "tunnel_vision": {
                "counterevidence": "Replace with evidence that the chosen approach is unnecessary or disproportionate.",
                "stop_or_change_if": "Replace with the threshold that stops or changes the approach.",
            },
            "failure_forecast": [
                {
                    "failure": "Replace with one credible failure mode.",
                    "safe_state": "Replace with the prior usable or explicitly quarantined state after failure.",
                    "proof_id": "focused-negative",
                }
            ],
            "sanity_check": {
                "claim": "Replace with a falsifiable claim that a reasonable engineer would accept.",
                "falsifier": "Replace with an observation that proves the slice is irrational or ineffective.",
                "proof_ids": ["focused-positive", "focused-negative"],
            },
        },
        "migration_hazards": {
            key: f"{name}: record the checked result or a specific reason it is not applicable."
            for key, name in architecture_catalogue(root, stewardship_policy(root))["migration_hazards"].items()
        },
        "acceptance": [
            {
                "id": "focused-positive",
                "category": "focused-positive",
                "proves": "Replace with the exact positive behavior this command demonstrates.",
                "argv": ["python3", "-m", "unittest", "replace.with.focused.positive.test"],
                "cwd": ".",
                "expected_exit_code": 0,
                "timeout_seconds": 3600,
            },
            {
                "id": "focused-negative",
                "category": "negative",
                "proves": "Replace with the malformed, failed or bypass behavior this command rejects.",
                "argv": ["python3", "-m", "unittest", "replace.with.focused.negative.test"],
                "cwd": ".",
                "expected_exit_code": 0,
                "timeout_seconds": 3600,
            },
            {
                "id": "full-regression",
                "category": "regression",
                "proves": "The complete repository test suite preserves all previously verified behavior.",
                "argv": ["python3", "-m", "unittest", "discover", "-s", "tests", "-p", "test_*.py"],
                "cwd": ".",
                "expected_exit_code": 0,
                "timeout_seconds": 3600,
            }
        ],
        "rollback": {
            "strategy": "git-revert-candidate",
            "steps": ["Revert the exact isolated candidate commit through the independent integration boundary."],
            "preserves": "Keep the recorded preflight starting commit as the last known-good state.",
            "verification_proof_ids": ["full-regression"],
        },
        "next_step": {"propose_only": True, "successor_authorized": False},
    }


def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(description="GIGA v2 deterministic development gate")
    sub = value.add_subparsers(dest="command", required=True)
    sub.add_parser("check", help="verify the constitutional foundation")
    template_parser = sub.add_parser("template", help="render a bound 24-hour work order")
    template_parser.add_argument("--lane", required=True)
    template_parser.add_argument("--id", required=True)
    template_parser.add_argument("--output", type=Path)
    admit_parser = sub.add_parser("admit", help="validate and admit one work order")
    admit_parser.add_argument("--work-order", required=True, type=Path)
    verify_parser = sub.add_parser("verify", help="verify a candidate against its admission")
    verify_parser.add_argument("--work-order", required=True, type=Path)
    verify_parser.add_argument("--preflight", required=True, type=Path)
    attest_parser = sub.add_parser("attest", help="bind a PASS completion receipt to an exact committed candidate")
    attest_parser.add_argument("--work-order", required=True, type=Path)
    attest_parser.add_argument("--preflight", required=True, type=Path)
    attest_parser.add_argument("--completion", required=True, type=Path)
    attest_parser.add_argument("--candidate-commit", default="HEAD")
    check_attestation_parser = sub.add_parser("check-attestation", help="validate a candidate-bound attestation")
    check_attestation_parser.add_argument("--attestation", required=True, type=Path)
    sub.add_parser("hook", help="enforce staged-path scope for lane commits")
    return value


def main(arguments: list[str] | None = None) -> int:
    args = parser().parse_args(arguments)
    try:
        root = find_root()
        if args.command == "check":
            print(json.dumps(check_foundation(root), indent=2, sort_keys=True))
            return 0
        if args.command == "template":
            if not ID_PATTERN.fullmatch(args.id):
                raise GateError("work order id is invalid")
            value = build_template(root, args.lane, args.id)
            if args.output:
                output = args.output if args.output.is_absolute() else root / args.output
                write_object(output, value)
                print(output)
            else:
                print(json.dumps(value, indent=2, sort_keys=True))
            return 0
        if args.command == "admit":
            path = args.work_order if args.work_order.is_absolute() else root / args.work_order
            print(admit(root, path))
            return 0
        if args.command == "verify":
            order_path = args.work_order if args.work_order.is_absolute() else root / args.work_order
            preflight_path = args.preflight if args.preflight.is_absolute() else root / args.preflight
            output, passed = verify(root, order_path, preflight_path)
            print(output)
            return 0 if passed else 1
        if args.command == "attest":
            order_path = args.work_order if args.work_order.is_absolute() else root / args.work_order
            preflight_path = args.preflight if args.preflight.is_absolute() else root / args.preflight
            completion_path = args.completion if args.completion.is_absolute() else root / args.completion
            print(attest_candidate(root, order_path, preflight_path, completion_path, args.candidate_commit))
            return 0
        if args.command == "check-attestation":
            attestation_path = args.attestation if args.attestation.is_absolute() else root / args.attestation
            print(json.dumps(check_attestation(root, attestation_path), indent=2, sort_keys=True))
            return 0
        if args.command == "hook":
            hook(root)
            return 0
        raise GateError(f"unknown command: {args.command}")
    except GateError as exc:
        print(f"REJECT: {exc}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
