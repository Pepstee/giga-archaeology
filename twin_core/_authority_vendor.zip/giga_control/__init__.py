"""Deterministic control boundary for GIGA v2 development work."""

__version__ = "0.1.0"

