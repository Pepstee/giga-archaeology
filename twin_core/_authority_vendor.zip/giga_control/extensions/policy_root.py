"""Validate and identify the versioned GIGA machine-policy root."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from pathlib import Path
import re
import stat
from typing import Any

from giga_control.gate import find_root


POLICY_PATH = "contracts/constitution/constitution.v1.json"
POLICY_SCHEMA = "giga-v2.constitution-policy.v1"
IDENTITY_SCHEMA = "giga-v2.official-policy-identity.v1"
POLICY_ID = "giga-v2-constitution"
POLICY_VERSION = "1.0.0"
IDENTITY_ALGORITHM = "sha256-canonical-json-without-policy-sha256"
RATIFIED_CONSTITUTION_VERSION = "2.1.0"
RATIFIED_CONSTITUTION_SHA256 = "dc278a45286ce712683e9660de353cc2c02e0b5d9fa935e96632259730f0c714"
CONSTITUTION_VERSION_PATTERN = re.compile(r"(?im)^\*\*Version:\*\*\s*([0-9]+(?:\.[0-9]+)*)\s*$")
MAX_SOURCE_BYTES = 1024 * 1024
PRECEDENCE = (
    "emergency-stop",
    "ratified-constitution",
    "current-explicit-operator-order-within-constitution",
    "admitted-work-order",
    "lane-contract",
    "implementation-default",
)


class PolicyRootError(ValueError):
    """The machine-policy root cannot produce an official identity."""


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=True, separators=(",", ":"), sort_keys=True).encode()


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def ratified_document_identity() -> dict[str, str]:
    return {
        "version": RATIFIED_CONSTITUTION_VERSION,
        "sha256": RATIFIED_CONSTITUTION_SHA256,
    }


def expected_body(document_identity: dict[str, str]) -> dict[str, Any]:
    if document_identity != ratified_document_identity():
        raise PolicyRootError("machine Constitution payload is not bound to the ratified Constitution identity")
    return {
        "schema": POLICY_SCHEMA,
        "policy_id": POLICY_ID,
        "version": POLICY_VERSION,
        "constitution_document": document_identity,
        "identity_algorithm": IDENTITY_ALGORITHM,
        "precedence": list(PRECEDENCE),
        "default_decision": "DENY",
        "unknown_input": "REJECT",
    }


def validate_payload(value: Any, document_identity: dict[str, str]) -> dict[str, Any]:
    if not isinstance(value, dict):
        raise PolicyRootError("machine Constitution payload must be a JSON object")
    expected = expected_body(document_identity)
    required = set(expected) | {"policy_sha256"}
    missing = sorted(required - value.keys())
    unknown = sorted(value.keys() - required)
    if missing:
        raise PolicyRootError(f"machine Constitution payload missing fields: {', '.join(missing)}")
    if unknown:
        raise PolicyRootError(f"machine Constitution payload contains unknown fields: {', '.join(unknown)}")
    for field, expected_value in expected.items():
        if value[field] != expected_value:
            raise PolicyRootError(f"machine Constitution payload has unsupported {field}")
    claimed = value["policy_sha256"]
    calculated = sha256_bytes(canonical_bytes(expected))
    if not isinstance(claimed, str) or claimed != calculated:
        raise PolicyRootError("machine Constitution payload identity does not match canonical policy bytes")
    return dict(value)


def _open_owned_file(root_fd: int, relative: str) -> tuple[int, int, str, os.stat_result]:
    components = Path(relative).parts
    directory_fd = os.dup(root_fd)
    file_fd: int | None = None
    try:
        for component in components[:-1]:
            next_fd = os.open(
                component,
                os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | getattr(os, "O_CLOEXEC", 0),
                dir_fd=directory_fd,
            )
            os.close(directory_fd)
            directory_fd = next_fd
        name = components[-1]
        file_fd = os.open(
            name,
            os.O_RDONLY | os.O_NOFOLLOW | getattr(os, "O_CLOEXEC", 0),
            dir_fd=directory_fd,
        )
        opened = os.fstat(file_fd)
        if not stat.S_ISREG(opened.st_mode):
            raise PolicyRootError(f"repository-owned source is not a regular file: {relative}")
        if opened.st_nlink != 1:
            raise PolicyRootError(f"repository-owned source must have exactly one hard link: {relative}")
        if opened.st_size > MAX_SOURCE_BYTES:
            raise PolicyRootError(f"repository-owned source exceeds the byte limit: {relative}")
        return file_fd, directory_fd, name, opened
    except (OSError, IndexError) as exc:
        if file_fd is not None:
            os.close(file_fd)
        os.close(directory_fd)
        raise PolicyRootError(f"repository-owned source path is missing, linked or invalid: {relative}") from exc
    except PolicyRootError:
        if file_fd is not None:
            os.close(file_fd)
        os.close(directory_fd)
        raise


def _read_bounded(file_fd: int) -> bytes:
    chunks: list[bytes] = []
    total = 0
    while True:
        chunk = os.read(file_fd, min(65536, MAX_SOURCE_BYTES + 1 - total))
        if not chunk:
            return b"".join(chunks)
        chunks.append(chunk)
        total += len(chunk)
        if total > MAX_SOURCE_BYTES:
            raise PolicyRootError("repository-owned source exceeds the byte limit while reading")


def _fingerprint(value: os.stat_result) -> tuple[int, int, int, int, int, int]:
    return (value.st_dev, value.st_ino, value.st_mode, value.st_nlink, value.st_size, value.st_mtime_ns)


def _verify_opened_entry(file_fd: int, directory_fd: int, name: str, opened: os.stat_result, relative: str) -> None:
    try:
        after = os.fstat(file_fd)
        entry = os.stat(name, dir_fd=directory_fd, follow_symlinks=False)
    except OSError as exc:
        raise PolicyRootError(f"repository-owned source changed while reading: {relative}") from exc
    if _fingerprint(after) != _fingerprint(opened):
        raise PolicyRootError(f"repository-owned source changed while reading: {relative}")
    if (entry.st_dev, entry.st_ino) != (opened.st_dev, opened.st_ino):
        raise PolicyRootError(f"repository-owned source path was substituted while reading: {relative}")
    if not stat.S_ISREG(entry.st_mode) or entry.st_nlink != 1:
        raise PolicyRootError(f"repository-owned source path became linked or invalid: {relative}")


def _verify_canonical_rewalk(root_fd: int, opened: os.stat_result, relative: str) -> None:
    current_file_fd: int | None = None
    current_directory_fd: int | None = None
    try:
        current_file_fd, current_directory_fd, _name, current = _open_owned_file(root_fd, relative)
        if (current.st_dev, current.st_ino) != (opened.st_dev, opened.st_ino):
            raise PolicyRootError(f"canonical repository path was replaced while reading: {relative}")
        if _fingerprint(current) != _fingerprint(opened):
            raise PolicyRootError(f"canonical repository source changed while reading: {relative}")
    finally:
        if current_file_fd is not None:
            os.close(current_file_fd)
        if current_directory_fd is not None:
            os.close(current_directory_fd)


def _document_identity(data: bytes) -> dict[str, str]:
    try:
        text = data.decode("utf-8")
    except UnicodeDecodeError as exc:
        raise PolicyRootError("ratified Constitution is not UTF-8") from exc
    match = CONSTITUTION_VERSION_PATTERN.search(text)
    if not match:
        raise PolicyRootError("ratified Constitution has no machine-readable version")
    return {"version": match.group(1), "sha256": sha256_bytes(data)}


def _read_policy_snapshot(root: Path) -> tuple[bytes, bytes]:
    try:
        resolved_root = root.resolve(strict=True)
        root_fd = os.open(
            resolved_root,
            os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | getattr(os, "O_CLOEXEC", 0),
        )
        opened_root = os.fstat(root_fd)
    except OSError as exc:
        raise PolicyRootError("machine Constitution root is missing or invalid") from exc
    opened: list[tuple[int, int, str, os.stat_result, str]] = []
    try:
        for relative in ("CONSTITUTION.md", POLICY_PATH):
            file_fd, directory_fd, name, metadata = _open_owned_file(root_fd, relative)
            opened.append((file_fd, directory_fd, name, metadata, relative))
        constitution_bytes = _read_bounded(opened[0][0])
        policy_bytes = _read_bounded(opened[1][0])
        for file_fd, directory_fd, name, metadata, relative in opened:
            _verify_opened_entry(file_fd, directory_fd, name, metadata, relative)
            _verify_canonical_rewalk(root_fd, metadata, relative)
        try:
            current_root = os.stat(resolved_root, follow_symlinks=False)
        except OSError as exc:
            raise PolicyRootError("machine Constitution root path changed while reading") from exc
        if (current_root.st_dev, current_root.st_ino) != (opened_root.st_dev, opened_root.st_ino):
            raise PolicyRootError("machine Constitution root path was replaced while reading")
        return constitution_bytes, policy_bytes
    finally:
        for file_fd, directory_fd, _name, _metadata, _relative in opened:
            os.close(file_fd)
            os.close(directory_fd)
        os.close(root_fd)


def load_payload(root: Path) -> dict[str, Any]:
    constitution_bytes, policy_bytes = _read_policy_snapshot(root)
    document_identity = _document_identity(constitution_bytes)
    if document_identity != ratified_document_identity():
        raise PolicyRootError("machine Constitution root does not contain the ratified Constitution identity")
    try:
        value = json.loads(policy_bytes.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise PolicyRootError("machine Constitution payload is missing or invalid") from exc
    return validate_payload(value, document_identity)


def official_identity(root: Path) -> dict[str, Any]:
    payload = load_payload(root)
    return {
        "schema": IDENTITY_SCHEMA,
        "policy_id": payload["policy_id"],
        "version": payload["version"],
        "policy_sha256": payload["policy_sha256"],
        "constitution_document": payload["constitution_document"],
        "precedence": payload["precedence"],
        "default_decision": payload["default_decision"],
        "unknown_input": payload["unknown_input"],
    }


def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(description=__doc__)
    value.add_argument("command", choices=("check", "identity"), nargs="?", default="check")
    return value


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        root = find_root()
        identity = official_identity(root)
        result = {"status": "PASS", "official_policy_identity": identity}
        if args.command == "identity":
            result = identity
        print(json.dumps(result, indent=2, sort_keys=True))
        return 0
    except PolicyRootError as exc:
        print(json.dumps({"status": "REJECT", "reason": str(exc)}, sort_keys=True))
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
