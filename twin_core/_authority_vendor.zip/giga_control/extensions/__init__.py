"""Non-protected, independently admitted extensions to the GIGA control boundary."""
