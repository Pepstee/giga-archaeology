"""Run the fixed GIGA-owned local verification inventory and emit bounded JSON."""

from __future__ import annotations

import argparse
import hashlib
import json
import os
from dataclasses import dataclass
from pathlib import Path
import signal
import stat
import subprocess
import sys
import tempfile
import threading
import time
from typing import Any, Callable, Iterable

from giga_control.gate import GateError, find_root, load_strict_object_bound


CONTRACT_SCHEMA = "giga-v2.local-verification-contract.v2"
RESULT_SCHEMA = "giga-v2.local-verification-result.v1"
CONTRACT_PATH = "contracts/constitution/local-verification.v2.json"
MAX_OUTPUT_BYTES = 1_048_576
MAX_SURFACE_BYTES = 64 * 1024 * 1024
MAX_SURFACE_ENTRIES = 20_000
POLL_SECONDS = 0.1
STATUSES = ("PASS", "FAILED", "MISSING", "INAPPLICABLE")
SANDBOX_EXECUTABLE = Path("/usr/bin/sandbox-exec")
PS_EXECUTABLE = Path("/bin/ps")
SYSTEM_READ_SUBPATHS = (
    Path("/System"),
    Path("/usr"),
    Path("/bin"),
    Path("/sbin"),
    Path("/opt/homebrew"),
    Path("/Library/Frameworks"),
    Path("/Library/Developer/CommandLineTools"),
)


class LocalVerificationError(RuntimeError):
    """The runner contract or invocation is invalid."""


@dataclass(frozen=True)
class CheckSpec:
    id: str
    argv: tuple[str, ...]
    required_paths: tuple[str, ...]
    timeout_seconds: int
    required: bool = True

    def contract_value(self) -> dict[str, Any]:
        return {
            "id": self.id,
            "argv": ["<python>" if value == sys.executable else value for value in self.argv],
            "required_paths": list(self.required_paths),
            "timeout_seconds": self.timeout_seconds,
            "required": self.required,
        }


CHECKS = (
    CheckSpec(
        "constitution-foundation",
        (sys.executable, "-B", "-s", "-m", "giga_control", "check"),
        ("CONSTITUTION.md", "giga_control", "control"),
        120,
    ),
    CheckSpec(
        "constitution-policy-root",
        (sys.executable, "-B", "-s", "-m", "giga_control.extensions.policy_root", "check"),
        ("contracts/constitution/constitution.v1.json", "giga_control/extensions/policy_root.py"),
        120,
    ),
    CheckSpec(
        "slice-registry",
        (
            sys.executable,
            "-B",
            "-s",
            "programme/slices/registry.py",
            "check",
            "--registry",
            "programme/slices/registry.json",
        ),
        ("programme/slices",),
        120,
    ),
    CheckSpec(
        "baseline-seal",
        (
            sys.executable,
            "-B",
            "-s",
            "src/giga_runtime/current_state_baseline.py",
            "verify-internal",
            "--receipt",
            "deploy/baselines/current-state.json",
        ),
        ("src/giga_runtime", "deploy/baselines/current-state.json"),
        120,
    ),
    CheckSpec(
        "constitution-tests",
        (
            sys.executable,
            "-B",
            "-s",
            "-m",
            "unittest",
            "tests.constitution.test_gate",
            "tests.constitution.test_stewardship_v3",
            "tests.constitution.test_policy_root",
            "tests.constitution.test_local_verification.LocalVerificationTests.test_fixed_contract_and_unknown_selection_fail_closed",
            "tests.constitution.test_local_verification.LocalVerificationTests.test_real_contract_lists_only_fixed_python_vectors",
            "tests.constitution.test_local_verification.LocalVerificationTests.test_git_metadata_binding_is_exact_and_rejects_unsafe_indirection",
        ),
        (
            "tests/constitution/test_gate.py",
            "tests/constitution/test_stewardship_v3.py",
            "tests/constitution/test_policy_root.py",
            "tests/constitution/test_local_verification.py",
            "giga_control",
            "contracts/constitution/constitution.v1.json",
            "contracts/constitution/development-stewardship.v3.json",
            "contracts/constitution/authority-sources/sha256",
        ),
        900,
    ),
    CheckSpec(
        "slice-registry-tests",
        (
            sys.executable,
            "-B",
            "-s",
            "-m",
            "unittest",
            "discover",
            "-s",
            "programme/slices/tests",
            "-p",
            "test_*.py",
        ),
        ("programme/slices",),
        900,
    ),
)


def canonical_bytes(value: Any) -> bytes:
    return json.dumps(value, ensure_ascii=True, separators=(",", ":"), sort_keys=True).encode()


def sha256_bytes(value: bytes) -> str:
    return hashlib.sha256(value).hexdigest()


def contract_body() -> dict[str, Any]:
    return {
        "schema": CONTRACT_SCHEMA,
        "command": "python3 -m giga_control.extensions.local_verify",
        "result_schema": RESULT_SCHEMA,
        "statuses": list(STATUSES),
        "exit_codes": {"PASS": 0, "FAILED": 1, "MISSING": 2, "INVALID": 3},
        "output_policy": {
            "raw_output_stored": False,
            "stream_limit_bytes_per_check": MAX_OUTPUT_BYTES,
            "stdout_stderr_sha256_recorded": True,
        },
        "surface_policy": {
            "symlinks_allowed": False,
            "max_entries": MAX_SURFACE_ENTRIES,
            "max_bytes": MAX_SURFACE_BYTES,
            "before_after_digest_required": True,
            "authenticity_claimed": False,
        },
        "confinement": {
            "platform": "macos-sandbox-exec",
            "writes": "scratch-only",
            "network": "denied",
            "caller_path_home_tmpdir_inherited": False,
            "descendant_cleanup": "freeze-enumerate-kill",
            "git_metadata": "exact-linked-worktree-directories-read-only-with-backlink-validation",
        },
        "selection_policy": "fixed-inventory-only-unselected-is-inapplicable",
        "top_level_status_semantics": "selected-check-outcome-only",
        "quality_boundary_semantics": "true-only-for-full-inventory-pass",
        "test_scope": {
            "included": "isolated-constitution-and-slice-registry-tests",
            "excluded": "live-cross-repository-and-nested-runtime-confinement-tests",
        },
        "checks": [spec.contract_value() for spec in CHECKS],
    }


def expected_contract() -> dict[str, Any]:
    value = contract_body()
    value["contract_sha256"] = sha256_bytes(canonical_bytes(value))
    return value


def load_contract(root: Path) -> dict[str, Any]:
    try:
        value = load_strict_object_bound(root, CONTRACT_PATH)
    except GateError as exc:
        raise LocalVerificationError("local verification contract is missing or invalid") from exc
    if value != expected_contract():
        raise LocalVerificationError("local verification contract differs from the fixed runner inventory")
    return value


def _sandbox_literal(path: Path | str) -> str:
    return str(path).replace("\\", "\\\\").replace('"', '\\"')


def _fixed_environment(scratch: Path) -> dict[str, str]:
    return {
        "PATH": "/Library/Developer/CommandLineTools/usr/bin:/usr/bin:/bin:/usr/sbin:/sbin",
        "HOME": str(scratch),
        "TMPDIR": str(scratch),
        "PYTHONNOUSERSITE": "1",
        "PYTHONDONTWRITEBYTECODE": "1",
        "DEVELOPER_DIR": "/Library/Developer/CommandLineTools",
        "GIT_CONFIG_NOSYSTEM": "1",
        "GIT_CONFIG_GLOBAL": "/dev/null",
        "LANG": "C.UTF-8",
    }


def _git_metadata_paths(root: Path) -> tuple[Path, ...]:
    """Return only the Git administrative directories bound to this checkout."""
    root = root.resolve(strict=True)
    dot_git = root / ".git"
    if not dot_git.exists() and not dot_git.is_symlink():
        return ()
    if dot_git.is_symlink():
        raise LocalVerificationError("repository Git metadata binding is missing or unsafe")
    if dot_git.is_dir():
        resolved = dot_git.resolve(strict=True)
        try:
            resolved.relative_to(root)
        except ValueError as exc:
            raise LocalVerificationError("Git metadata directory escapes repository") from exc
        return (resolved,)
    if not dot_git.is_file() or dot_git.is_symlink():
        raise LocalVerificationError("repository Git metadata binding is missing or unsafe")
    try:
        marker = dot_git.read_text(encoding="utf-8").strip()
    except OSError as exc:
        raise LocalVerificationError("repository Git metadata binding is unreadable") from exc
    prefix = "gitdir: "
    if not marker.startswith(prefix) or "\n" in marker:
        raise LocalVerificationError("repository Git metadata binding is invalid")
    declared = Path(marker[len(prefix) :])
    git_dir = (
        (root / declared).resolve(strict=True)
        if not declared.is_absolute()
        else declared.resolve(strict=True)
    )
    if not git_dir.is_dir() or git_dir.parent.name != "worktrees":
        raise LocalVerificationError("linked-worktree Git directory has an invalid shape")
    try:
        backlink_path = Path((git_dir / "gitdir").read_text(encoding="utf-8").strip()).resolve(
            strict=True
        )
    except OSError as exc:
        raise LocalVerificationError("linked-worktree Git backlink is missing") from exc
    if backlink_path != dot_git.resolve(strict=True):
        raise LocalVerificationError("linked-worktree Git backlink differs from checkout")
    try:
        common_declared = Path((git_dir / "commondir").read_text(encoding="utf-8").strip())
    except OSError as exc:
        raise LocalVerificationError("linked-worktree common Git directory is missing") from exc
    common_dir = (
        (git_dir / common_declared).resolve(strict=True)
        if not common_declared.is_absolute()
        else common_declared.resolve(strict=True)
    )
    if not common_dir.is_dir() or common_dir.name != ".git" or git_dir.parent.parent != common_dir:
        raise LocalVerificationError("linked-worktree common Git directory has an invalid shape")
    return (git_dir, common_dir)


def _sandbox_profile(root: Path, scratch: Path) -> str:
    read_paths = (
        *SYSTEM_READ_SUBPATHS,
        root.resolve(),
        scratch.resolve(),
        *_git_metadata_paths(root),
    )
    read_files = (Path("/etc/gitattributes"),)
    read_rules = [f'(allow file-read* (subpath "{_sandbox_literal(path)}"))' for path in read_paths]
    read_rules.extend(
        f'(allow file-read* (literal "{_sandbox_literal(path)}"))'
        for path in (
            "/",
            "/dev/null",
            "/dev/urandom",
            "/private/etc/localtime",
            *read_files,
        )
    )
    read_rules.append('(allow file-read-data (literal "/dev/fd"))')
    parents = sorted(
        {
            parent
            for path in (*read_paths, *read_files)
            for parent in path.parents
            if str(parent) != "/"
        },
        key=str,
    )
    read_rules.extend(
        f'(allow file-read-metadata (literal "{_sandbox_literal(path)}"))' for path in parents
    )
    return " ".join(
        [
            "(version 1)",
            "(deny default)",
            "(allow process*)",
            *read_rules,
            f'(allow file-write* (subpath "{_sandbox_literal(scratch)}"))',
            '(allow file-write* (literal "/dev/null"))',
            "(deny network*)",
        ]
    )


def _descendant_pids(parent_pid: int) -> set[int]:
    try:
        result = subprocess.run(
            [str(PS_EXECUTABLE), "-axo", "pid=,ppid="],
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            env={"PATH": "/usr/bin:/bin", "LANG": "C"},
            timeout=5,
        )
    except (OSError, subprocess.SubprocessError):
        return set()
    children: dict[int, set[int]] = {}
    for line in result.stdout.decode("ascii", "ignore").splitlines():
        fields = line.split()
        if len(fields) != 2 or not all(value.isdigit() for value in fields):
            continue
        pid, ppid = map(int, fields)
        children.setdefault(ppid, set()).add(pid)
    found: set[int] = set()
    pending = [parent_pid]
    while pending:
        current = pending.pop()
        for child in children.get(current, set()):
            if child not in found:
                found.add(child)
                pending.append(child)
    return found


def _signal_pid(pid: int, action: int) -> None:
    try:
        os.kill(pid, action)
    except (ProcessLookupError, PermissionError):
        pass


def _terminate_tree(process: subprocess.Popen[bytes], known: set[int]) -> None:
    try:
        os.killpg(process.pid, signal.SIGSTOP)
    except (ProcessLookupError, PermissionError):
        pass
    for _ in range(4):
        observed = _descendant_pids(process.pid)
        new = observed - known
        known.update(observed)
        for pid in observed:
            _signal_pid(pid, signal.SIGSTOP)
        if not new:
            break
    for pid in sorted(known, reverse=True):
        _signal_pid(pid, signal.SIGKILL)
    try:
        os.killpg(process.pid, signal.SIGKILL)
    except (ProcessLookupError, PermissionError):
        process.kill()


def _surface_digest(root: Path, required_paths: tuple[str, ...]) -> str:
    root = root.resolve(strict=True)
    entries: dict[str, dict[str, Any]] = {}
    total_bytes = 0
    for relative in required_paths:
        path = root / relative
        resolved = path.resolve(strict=True)
        try:
            resolved.relative_to(root)
        except ValueError as exc:
            raise LocalVerificationError(f"owned surface escapes repository: {relative}") from exc
        candidates = [path]
        if path.is_dir():
            candidates.extend(sorted(path.rglob("*"), key=lambda value: value.as_posix()))
        for candidate in candidates:
            rel = candidate.relative_to(root).as_posix()
            if candidate.is_symlink():
                raise LocalVerificationError(f"owned surface contains symlink: {rel}")
            metadata = candidate.lstat()
            if stat.S_ISDIR(metadata.st_mode):
                value = {"kind": "directory", "mode": stat.S_IMODE(metadata.st_mode)}
            elif stat.S_ISREG(metadata.st_mode):
                total_bytes += metadata.st_size
                if total_bytes > MAX_SURFACE_BYTES:
                    raise LocalVerificationError("owned surface exceeds byte limit")
                value = {
                    "kind": "file",
                    "mode": stat.S_IMODE(metadata.st_mode),
                    "size": metadata.st_size,
                    "sha256": sha256_bytes(candidate.read_bytes()),
                }
            else:
                raise LocalVerificationError(f"owned surface contains special file: {rel}")
            entries[rel] = value
            if len(entries) > MAX_SURFACE_ENTRIES:
                raise LocalVerificationError("owned surface exceeds entry limit")
    return sha256_bytes(canonical_bytes(entries))


def execute_bounded(spec: CheckSpec, root: Path) -> dict[str, Any]:
    empty_hash = hashlib.sha256().hexdigest()
    try:
        scratch_context = tempfile.TemporaryDirectory(prefix="giga-local-verify-", dir="/private/tmp")
    except OSError as exc:
        return {
            "exit_code": None,
            "timed_out": False,
            "output_limited": False,
            "spawn_error": type(exc).__name__,
            "sandboxed": False,
            "stdout_bytes": 0,
            "stderr_bytes": 0,
            "stdout_sha256": empty_hash,
            "stderr_sha256": empty_hash,
        }
    scratch = Path(scratch_context.name).resolve()
    try:
        argv = [str(SANDBOX_EXECUTABLE), "-p", _sandbox_profile(root, scratch), *spec.argv]
        process = subprocess.Popen(
            argv,
            cwd=root,
            env=_fixed_environment(scratch),
            stdin=subprocess.DEVNULL,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            start_new_session=True,
        )
    except (OSError, LocalVerificationError) as exc:
        scratch_context.cleanup()
        return {
            "exit_code": None,
            "timed_out": False,
            "output_limited": False,
            "spawn_error": type(exc).__name__,
            "sandboxed": False,
            "stdout_bytes": 0,
            "stderr_bytes": 0,
            "stdout_sha256": empty_hash,
            "stderr_sha256": empty_hash,
        }
    digests = {"stdout": hashlib.sha256(), "stderr": hashlib.sha256()}
    counts = {"stdout": 0, "stderr": 0}
    limited = threading.Event()

    def consume(name: str, stream: Any) -> None:
        while chunk := stream.read(65_536):
            counts[name] += len(chunk)
            if counts[name] > MAX_OUTPUT_BYTES:
                limited.set()
                return
            digests[name].update(chunk)

    threads = [
        threading.Thread(target=consume, args=("stdout", process.stdout), daemon=True),
        threading.Thread(target=consume, args=("stderr", process.stderr), daemon=True),
    ]
    for thread in threads:
        thread.start()
    deadline = time.monotonic() + spec.timeout_seconds
    timed_out = False
    descendants: set[int] = set()
    while process.poll() is None:
        descendants.update(_descendant_pids(process.pid))
        if limited.is_set():
            _terminate_tree(process, descendants)
            break
        if time.monotonic() >= deadline:
            timed_out = True
            _terminate_tree(process, descendants)
            break
        time.sleep(POLL_SECONDS)
    process.wait()
    for pid in descendants:
        _signal_pid(pid, signal.SIGKILL)
    for thread in threads:
        thread.join(timeout=1)
    if process.stdout is not None:
        process.stdout.close()
    if process.stderr is not None:
        process.stderr.close()
    result = {
        "exit_code": process.returncode,
        "timed_out": timed_out,
        "output_limited": limited.is_set(),
        "spawn_error": None,
        "sandboxed": True,
        "stdout_bytes": min(counts["stdout"], MAX_OUTPUT_BYTES),
        "stderr_bytes": min(counts["stderr"], MAX_OUTPUT_BYTES),
        "stdout_sha256": digests["stdout"].hexdigest(),
        "stderr_sha256": digests["stderr"].hexdigest(),
    }
    scratch_context.cleanup()
    return result


def _inapplicable(spec: CheckSpec) -> dict[str, Any]:
    return {
        "id": spec.id,
        "required": spec.required,
        "status": "INAPPLICABLE",
        "reason": "not-selected",
        "exit_code": None,
        "timed_out": False,
        "output_limited": False,
        "spawn_error": None,
        "sandboxed": False,
        "surface_sha256": None,
        "stdout_bytes": 0,
        "stderr_bytes": 0,
        "stdout_sha256": None,
        "stderr_sha256": None,
    }


def run_checks(
    root: Path,
    *,
    selected: Iterable[str] | None = None,
    specs: tuple[CheckSpec, ...] = CHECKS,
    executor: Callable[[CheckSpec, Path], dict[str, Any]] = execute_bounded,
) -> tuple[dict[str, Any], int]:
    selected_ids = set(selected) if selected is not None else {spec.id for spec in specs}
    known_ids = {spec.id for spec in specs}
    unknown = sorted(selected_ids - known_ids)
    if unknown:
        raise LocalVerificationError(f"unknown check identifiers: {', '.join(unknown)}")
    results: list[dict[str, Any]] = []
    root = root.resolve(strict=True)
    for spec in specs:
        if spec.id not in selected_ids:
            results.append(_inapplicable(spec))
            continue
        missing = [value for value in spec.required_paths if not (root / value).exists()]
        if missing:
            results.append(
                {
                    **_inapplicable(spec),
                    "status": "MISSING",
                    "reason": "required-path-missing",
                    "missing_paths": missing,
                }
            )
            continue
        try:
            surface_before = _surface_digest(root, spec.required_paths)
        except (LocalVerificationError, OSError) as exc:
            results.append(
                {
                    **_inapplicable(spec),
                    "status": "FAILED",
                    "reason": "unsafe-owned-surface",
                    "surface_error": str(exc),
                }
            )
            continue
        observed = executor(spec, root)
        try:
            surface_after = _surface_digest(root, spec.required_paths)
        except (LocalVerificationError, OSError):
            surface_after = None
        surface_changed = surface_after != surface_before
        observed = {
            "spawn_error": None,
            "sandboxed": False,
            **observed,
            "surface_sha256": surface_before,
        }
        failed = (
            observed["exit_code"] != 0
            or observed["timed_out"]
            or observed["output_limited"]
            or observed["spawn_error"] is not None
            or surface_changed
        )
        reason = None
        if observed["spawn_error"] is not None:
            reason = "spawn-error"
        elif surface_changed:
            reason = "owned-surface-changed"
        elif observed["timed_out"]:
            reason = "timeout"
        elif observed["output_limited"]:
            reason = "output-limit"
        elif observed["exit_code"] != 0:
            reason = "nonzero-exit"
        results.append(
            {
                "id": spec.id,
                "required": spec.required,
                "status": "FAILED" if failed else "PASS",
                "reason": reason,
                **observed,
            }
        )
    blocking = [value for value in results if value["required"] and value["status"] in {"FAILED", "MISSING"}]
    counts = {status: sum(value["status"] == status for value in results) for status in STATUSES}
    full_inventory = selected_ids == known_ids
    report = {
        "schema": RESULT_SCHEMA,
        "status": "FAIL" if blocking else "PASS",
        "coverage": "FULL" if full_inventory else "PARTIAL",
        "quality_boundary_satisfied": not blocking and full_inventory,
        "contract_sha256": expected_contract()["contract_sha256"],
        "runner_implementation_sha256": sha256_bytes(Path(__file__).read_bytes()),
        "surface_claim": "current-worktree-integrity-only-not-authenticity",
        "selected_checks": sorted(selected_ids),
        "counts": counts,
        "results": results,
    }
    if any(value["status"] == "MISSING" for value in blocking):
        return report, 2
    if blocking:
        return report, 1
    return report, 0


def parser() -> argparse.ArgumentParser:
    value = argparse.ArgumentParser(description=__doc__)
    value.add_argument(
        "--checks",
        help="Comma-separated subset of the fixed inventory; unselected checks are INAPPLICABLE.",
    )
    value.add_argument("--list", action="store_true", help="Print the fixed contract without running checks.")
    return value


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    try:
        root = find_root()
        contract = load_contract(root)
        if args.list:
            print(json.dumps(contract, indent=2, sort_keys=True))
            return 0
        selected = None
        if args.checks is not None:
            selected = [value.strip() for value in args.checks.split(",") if value.strip()]
            if not selected:
                raise LocalVerificationError("--checks must name at least one fixed check")
        report, exit_code = run_checks(root, selected=selected)
        print(json.dumps(report, indent=2, sort_keys=True))
        return exit_code
    except LocalVerificationError as exc:
        print(json.dumps({"schema": RESULT_SCHEMA, "status": "INVALID", "reason": str(exc)}, sort_keys=True))
        return 3


if __name__ == "__main__":
    raise SystemExit(main())
