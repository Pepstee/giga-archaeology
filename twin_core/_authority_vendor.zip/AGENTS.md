# GIGA v2 agent instructions

These instructions apply to every Codex task and nested directory in this repository.

## Required reading

Before substantive work, read in order:

1. `CONSTITUTION.md`
2. `control/lanes.json`
3. `docs/OPERATING_MANUAL.md`
4. the brief for the task's named lane
5. `contracts/constitution/DEVELOPMENT_STEWARDSHIP.md`

## Admission rule

- Read-only inspection and planning may proceed without a work order.
- Any file mutation requires an admitted `giga-v2.work-order.v2` document.
- Run `python3 -m giga_control check` before planning a mutation.
- Run `python3 -m giga_control admit --work-order <path>` before editing.
- Keep `GIGA_WORK_ORDER=<path>` set when committing so the pre-commit gate can check lane scope.
- Run `python3 -m giga_control verify --work-order <path> --preflight <path>` before claiming done.
- Commit the verified candidate, then run `python3 -m giga_control attest --work-order <path>
  --preflight <path> --completion <path> --candidate-commit <commit>`.
- A PASS completion receipt and candidate-bound attestation are necessary but do not merge the candidate.

## Non-negotiable development rules

- Work in an isolated worktree; never write concurrently in the protected shared checkout.
- Stay inside the lane's registered path prefixes and the narrower work-order allowlist.
- Search for reusable implementations in this repository and registered upstream sources first.
- Implement one smallest useful end-to-end increment; do not consume a backlog automatically.
- Cite exact JSR, operator-requirement, architectural-law, layer and target-source identities in the
  structured work order. Record hallucination, scope, context, nuance, tunnel-vision, failure and
  falsifiable sanity controls before implementation.
- Never modify `CONSTITUTION.md`, its lock, the lane registry, hooks or the gate judging your work.
- Never use `--no-verify`, disable hooks or weaken an acceptance command.
- Never access the Personal Vault, credentials or external-write tools without a distinct operator
  capability grant. Foundation development work orders do not carry such grants.
- Preserve unrelated user changes. Do not reset, clean, overwrite or absorb them.
- Stop on expiry, STOP, repeated failure, missing authority, scope expansion or an already adequate
  canonical implementation.

## Completion language

Use `PROPOSED`, `ADMITTED`, `RUNNING`, `PAUSED`, `BLOCKED`, `REJECTED` or `VERIFIED`. Do not call work
complete unless the deterministic completion receipt says `PASS` and all external claims have the
required affected-system evidence.
