# GIGA v2 operating manual

## Shared project, isolated work

All lane definitions, contracts and accepted state live in this repository. Writable Codex tasks use
Git worktrees so two lanes do not edit one checkout. They share history and contracts, not mutable
working files.

## Manual lane use

1. Open the appropriate saved Codex task.
2. Ask questions or inspect freely in read-only mode.
3. For a change, write one work order from `work_orders/TEMPLATE.json`.
4. Bind it to the current Constitution hash and choose only lane-owned paths.
5. Complete its structured architecture trace, rationale, AI-failure controls, H1-H8 review and
   positive/negative/regression proofs. Placeholder templates are intentionally inadmissible.
6. Admit it, implement the smallest useful increment, verify it and retain the completion receipt.
7. Commit the candidate and create a post-commit attestation that binds the verified payload to the
   exact candidate commit.
8. Review and integrate the candidate separately.

## Bounded 24-hour goal use

Give the lane a concrete outcome, not a backlog. Suggested prompt:

> Pursue a goal for at most 24 hours: [one independently useful outcome]. Work only in the [lane]
> lane. First create and admit one work order with exact non-goals, paths, verification and rollback.
> Stop when verified, blocked, expired or after two failed approaches. Do not begin another slice.

The work-order expiry is the deterministic authority limit. A chat instruction cannot extend it.

## Integration rule

Lane tasks produce candidates. The shared checkout accepts a candidate only after:

- the Constitution lock is valid;
- the work order and preflight receipt validate;
- changed paths remain within scope and avoid protected policy files;
- acceptance commands pass;
- completion receipt self-hash validates; and
- the post-commit attestation names the exact candidate commit and verified payload; and
- an independent assurance review finds no unsupported external claim.

## STOP and recovery

For now, stop a task in Codex and do not integrate its candidate. The later runtime STOP service will
add authenticated remote control; the foundation already treats an absent or expired authority as a
hard rejection.
