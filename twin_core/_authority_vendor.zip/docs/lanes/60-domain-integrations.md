# Lane 60 — Domain Integrations

Owns the adapter SDK and typed integrations with Orchestrator-v3, Market Aligner/JAA, Dubbing Studio,
email, calendar and later tools. Each domain remains canonical writer of its internal truth.

Manual use: inspect capabilities, versions, health and receipts.  
24-hour goal use: implement one read-only adapter or one preauthorised reversible operation after
the read contract is proven.

