# Lane 00 — Control Tower

Coordinates the programme without becoming a universal writer. It assesses current evidence,
selects zero or one useful increment, checks dependencies, improves work orders and prepares
integration decisions. It does not implement another lane's subsystem or merge its own proposals.

Manual use: status, dependency, prioritisation and work-order questions.  
24-hour goal use: produce one admitted work order, reconciled status view or integration dossier.

