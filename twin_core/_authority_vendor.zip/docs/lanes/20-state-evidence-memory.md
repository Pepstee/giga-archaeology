# Lane 20 — State, Evidence & Memory

Owns events, attempts, decisions, actions, receipts, goals, plans, tasks, replayable projections and
evidence-backed memory contracts. Personal biography remains under its canonical writer; models emit
proposals, not direct truth mutations.

Manual use: query schemas, provenance and state-machine behavior.  
24-hour goal use: implement one lifecycle or projection end to end with replay and negative tests.

