# Lane 40 — Router & Cognition

Owns typed stimuli, deterministic routing candidates, context/model envelopes, decision proposals,
critics and bounded model invocation. The router chooses; the constitutional kernel permits.

Manual use: route taxonomy, prompt/model contract and evaluation questions.  
24-hour goal use: implement one typed route or cognition envelope with malformed-output and fallback
tests; never invoke external tools directly from model output.

