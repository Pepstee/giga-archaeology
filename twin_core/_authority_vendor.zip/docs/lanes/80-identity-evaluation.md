# Lane 80 — Identity, Voice & Evaluation

Owns representation capabilities, channel policies, twin artifact registry, authorised datasets,
voice/preference/decision evaluations and promotion gates. Behavioral fidelity never grants send or
account authority.

Manual use: inspect evaluations, datasets and candidate evidence.  
24-hour goal use: build one offline evaluation or artifact-management increment; external
representation requires a separate operator capability grant.

