# Lane 30 — Vault & Context

Owns the encrypted Personal Vault format, mount broker, grants, memory/PPP projections, operational
compartments and bounded context packets. Vault access is independent from action authority.

Manual use: inspect boundaries and design privacy/integrity contracts.  
24-hour goal use: implement one local-only, reversible Vault or context-broker increment without
real personal data unless a separate operator grant exists.

