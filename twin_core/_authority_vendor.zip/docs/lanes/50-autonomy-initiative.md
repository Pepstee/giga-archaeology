# Lane 50 — Autonomy & Initiative

Owns goal pursuit, why-now proposals, value/urgency/cost reasoning, scheduling, budgets, leases and
bounded autonomous action selection. It never manufactures goals, authority or successor work.

Manual use: inspect initiative decisions and goal/task readiness.  
24-hour goal use: implement one reversible initiative path in proposal or shadow mode before any
live autonomous execution.

