from __future__ import annotations

import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest import mock

from giga_control.extensions import local_verify


ROOT = Path(__file__).resolve().parents[2]
DEV_FD_RULE = '(allow file-read-data (literal "/dev/fd"))'


class SandboxProfilePortabilityTests(unittest.TestCase):
    def profile(self) -> str:
        with tempfile.TemporaryDirectory() as temporary:
            return local_verify._sandbox_profile(ROOT, Path(temporary))

    def test_profile_contains_exactly_the_dev_fd_read_rule_and_no_subpath_grant(self) -> None:
        profile = self.profile()
        self.assertIn(DEV_FD_RULE, profile)
        self.assertEqual(1, profile.count('/dev/fd"'))
        self.assertNotIn('(subpath "/dev', profile)
        self.assertNotIn('file-write* (literal "/dev/fd")', profile)

    def test_generated_profile_contains_no_external_architecture_or_personal_path(self) -> None:
        profile = self.profile()
        self.assertNotIn("giga-user/architecture", profile)
        self.assertNotIn("11_JARVIS_SOVEREIGN_RUNTIME", profile)
        self.assertNotIn("12_JARVIS_SOVEREIGN_RUNTIME", profile)
        self.assertNotIn("upstream_path", profile)
        self.assertIn(f'(allow file-read* (subpath "{ROOT.resolve()}"))', profile)
        self.assertNotIn(str(ROOT / "contracts/constitution/authority-sources"), profile)

    def test_runner_source_no_longer_discovers_external_architecture(self) -> None:
        text = (ROOT / "giga_control/extensions/local_verify.py").read_text(encoding="utf-8")
        self.assertNotIn("_architecture_source_paths", text)
        self.assertNotIn("upstream_path", text)
        self.assertNotIn("local-verification.v1.json", text)
        self.assertIn("giga-v2.local-verification-contract.v2", text)


class LocalVerificationTests(unittest.TestCase):
    def spec(
        self,
        identifier: str,
        code: str,
        *,
        required_paths: tuple[str, ...] = ("marker",),
        timeout: int = 5,
    ) -> local_verify.CheckSpec:
        return local_verify.CheckSpec(
            identifier,
            (sys.executable, "-B", "-s", "-c", code),
            required_paths,
            timeout,
        )

    def test_pass_and_inapplicable_are_structured(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "marker").write_text("owned\n", encoding="utf-8")
            specs = (
                self.spec("selected-pass", "print('bounded pass')"),
                self.spec("not-selected", "raise SystemExit(9)"),
            )
            report, exit_code = local_verify.run_checks(
                root,
                selected=["selected-pass"],
                specs=specs,
            )

        self.assertEqual(0, exit_code)
        self.assertEqual("PASS", report["status"])
        self.assertEqual("PARTIAL", report["coverage"])
        self.assertFalse(report["quality_boundary_satisfied"])
        self.assertEqual(
            {"PASS": 1, "FAILED": 0, "MISSING": 0, "INAPPLICABLE": 1},
            report["counts"],
        )
        self.assertEqual("PASS", report["results"][0]["status"])
        self.assertEqual("INAPPLICABLE", report["results"][1]["status"])
        self.assertIsNone(report["results"][1]["exit_code"])
        self.assertNotIn("stdout", report["results"][0])
        self.assertNotIn("stderr", report["results"][0])
        self.assertEqual(64, len(report["results"][0]["stdout_sha256"]))

    def test_failed_missing_timeout_and_output_limit_are_nonzero(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "marker").write_text("owned\n", encoding="utf-8")
            specs = (
                self.spec("failed", "raise SystemExit(7)"),
                self.spec("missing", "raise SystemExit(0)", required_paths=("absent",)),
                self.spec("timeout", "import time; time.sleep(5)", timeout=1),
                self.spec(
                    "output-limit",
                    f"import os; os.write(1, b'x' * {local_verify.MAX_OUTPUT_BYTES + 1})",
                ),
            )
            report, exit_code = local_verify.run_checks(root, specs=specs)

        self.assertEqual(2, exit_code)
        self.assertEqual("FAIL", report["status"])
        self.assertEqual("FULL", report["coverage"])
        self.assertFalse(report["quality_boundary_satisfied"])
        by_id = {value["id"]: value for value in report["results"]}
        self.assertEqual(("FAILED", "nonzero-exit"), (by_id["failed"]["status"], by_id["failed"]["reason"]))
        self.assertEqual(("MISSING", "required-path-missing"), (by_id["missing"]["status"], by_id["missing"]["reason"]))
        self.assertEqual(("FAILED", "timeout"), (by_id["timeout"]["status"], by_id["timeout"]["reason"]))
        self.assertEqual(
            ("FAILED", "output-limit"),
            (by_id["output-limit"]["status"], by_id["output-limit"]["reason"]),
        )
        self.assertTrue(by_id["timeout"]["timed_out"])
        self.assertTrue(by_id["output-limit"]["output_limited"])

    def test_fixed_contract_and_unknown_selection_fail_closed(self) -> None:
        contract = local_verify.expected_contract()
        body = dict(contract)
        receipt = body.pop("contract_sha256")
        self.assertEqual(receipt, local_verify.sha256_bytes(local_verify.canonical_bytes(body)))
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            with self.assertRaisesRegex(local_verify.LocalVerificationError, "unknown check"):
                local_verify.run_checks(root, selected=["invented-command"], specs=())

    def test_real_contract_lists_only_fixed_python_vectors(self) -> None:
        root = Path(__file__).resolve().parents[2]
        contract = local_verify.load_contract(root)
        self.assertEqual([spec.contract_value() for spec in local_verify.CHECKS], contract["checks"])
        for check in contract["checks"]:
            self.assertEqual("<python>", check["argv"][0])
            self.assertNotIn("sh", check["argv"])
            self.assertNotIn("bash", check["argv"])

    def test_cli_unknown_check_is_stable_invalid(self) -> None:
        root = Path(__file__).resolve().parents[2]
        result = subprocess.run(
            [sys.executable, "-B", "-s", "-m", "giga_control.extensions.local_verify", "--checks", "invented"],
            cwd=root,
            check=False,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        self.assertEqual(3, result.returncode)
        value = json.loads(result.stdout)
        self.assertEqual("INVALID", value["status"])
        self.assertEqual("", result.stderr)

    def test_caller_path_injection_and_external_effects_are_confined(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "marker").write_text("owned\n", encoding="utf-8")
            shim_root = root / "shim"
            shim_root.mkdir()
            sentinel = Path(temporary).parent / f"giga-runner-sentinel-{os.getpid()}"
            shim = shim_root / "git"
            shim.write_text(
                f"#!/bin/sh\nprintf injected > '{sentinel}'\nexec /usr/bin/git \"$@\"\n",
                encoding="utf-8",
            )
            shim.chmod(0o755)
            spec = self.spec(
                "fixed-path",
                "import subprocess; subprocess.run(['git', '--version'], check=True)",
            )
            with mock.patch.dict(os.environ, {"PATH": f"{shim_root}:{os.environ.get('PATH', '')}"}):
                report, exit_code = local_verify.run_checks(root, specs=(spec,))
            self.assertEqual(0, exit_code)
            self.assertTrue(report["quality_boundary_satisfied"])
            self.assertFalse(sentinel.exists())

            victim = subprocess.Popen(["/bin/sleep", "30"])
            external = Path(temporary).parent / f"giga-runner-external-{os.getpid()}"
            effect_code = (
                "import os,signal,socket; "
                f"target={str(external)!r}; victim={victim.pid}; "
                "\ntry: open(target,'w').write('bad')\nexcept OSError: pass\n"
                "try: socket.create_connection(('127.0.0.1',9),timeout=.1)\nexcept OSError: pass\n"
                "try: os.kill(victim,signal.SIGKILL)\nexcept OSError: pass\n"
            )
            effect = self.spec("effects", effect_code)
            try:
                report, exit_code = local_verify.run_checks(root, specs=(effect,))
                self.assertEqual(0, exit_code)
                self.assertTrue(report["results"][0]["sandboxed"])
                self.assertFalse(external.exists())
                self.assertIsNone(victim.poll())
            finally:
                victim.terminate()
                victim.wait(timeout=5)

    def test_symlink_escape_rejects_before_execution(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary) / "root"
            root.mkdir()
            external = Path(temporary) / "external.py"
            sentinel = Path(temporary) / "sentinel"
            external.write_text(f"open({str(sentinel)!r}, 'w').write('bad')\n", encoding="utf-8")
            (root / "entry.py").symlink_to(external)
            spec = local_verify.CheckSpec(
                "symlink",
                (sys.executable, "-B", "-s", "entry.py"),
                ("entry.py",),
                5,
            )
            report, exit_code = local_verify.run_checks(root, specs=(spec,))
            self.assertEqual(1, exit_code)
            self.assertEqual("unsafe-owned-surface", report["results"][0]["reason"])
            self.assertFalse(sentinel.exists())

    def test_git_metadata_binding_is_exact_and_rejects_unsafe_indirection(self) -> None:
        real_root = Path(__file__).resolve().parents[2]
        metadata = local_verify._git_metadata_paths(real_root)
        self.assertIn(len(metadata), {1, 2})
        self.assertTrue(all(path.is_dir() for path in metadata))
        if len(metadata) == 1:
            self.assertEqual((real_root / ".git").resolve(strict=True), metadata[0])
        else:
            self.assertEqual("worktrees", metadata[0].parent.name)
            self.assertEqual(".git", metadata[1].name)

        with tempfile.TemporaryDirectory() as temporary:
            primary = Path(temporary) / "primary"
            subprocess.run(
                ["/usr/bin/git", "init", "--quiet", str(primary)],
                check=True,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
            )
            self.assertEqual(((primary / ".git").resolve(strict=True),), local_verify._git_metadata_paths(primary))

        with tempfile.TemporaryDirectory() as temporary:
            parent = Path(temporary)
            root = parent / "checkout"
            root.mkdir()
            unsafe = parent / "outside"
            unsafe.mkdir()
            (root / ".git").symlink_to(unsafe, target_is_directory=True)
            with self.assertRaisesRegex(local_verify.LocalVerificationError, "missing or unsafe"):
                local_verify._git_metadata_paths(root)

    def test_detached_descendant_is_killed_and_spawn_error_is_structured(self) -> None:
        marker = f"giga-detached-{os.getpid()}-{time.time_ns()}"
        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            (root / "marker").write_text("owned\n", encoding="utf-8")
            code = (
                "import subprocess,sys,time; "
                f"subprocess.Popen([sys.executable,'-c','import time; time.sleep(30)',{marker!r}],"
                "start_new_session=True); time.sleep(30)"
            )
            timed = self.spec("detached", code, timeout=1)
            report, exit_code = local_verify.run_checks(root, specs=(timed,))
            self.assertEqual(1, exit_code)
            self.assertEqual("timeout", report["results"][0]["reason"])
            process_list = subprocess.run(
                ["/bin/ps", "-axo", "args="],
                check=True,
                stdout=subprocess.PIPE,
                text=True,
            ).stdout
            self.assertNotIn(marker, process_list)

            with mock.patch.object(local_verify, "SANDBOX_EXECUTABLE", Path("/definitely/missing/sandbox")):
                report, exit_code = local_verify.run_checks(root, specs=(self.spec("spawn", "pass"),))
            self.assertEqual(1, exit_code)
            self.assertEqual("spawn-error", report["results"][0]["reason"])
            self.assertEqual("FileNotFoundError", report["results"][0]["spawn_error"])


if __name__ == "__main__":
    unittest.main()
