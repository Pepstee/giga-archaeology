from __future__ import annotations

import datetime as dt
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

from giga_control.gate import (
    GateError,
    attest_candidate,
    admit,
    build_template,
    check_attestation,
    check_foundation,
    constitution_identity,
    load_object,
    self_bound,
    validate_work_order,
    valid_self_hash,
    verify,
    write_object,
)


ROOT = Path(__file__).resolve().parents[2]
ARCHITECTURE_HASHES = [
    "fc65e8221416178eb3c7ef2801b4e631269853926a648683648dc7cc293dc245",
    "eebb08490dcba120f793f4a5c513a71accefa0d4871c2b05f24d8d1d6a3ae6a8",
]


def run(*arguments: str, cwd: Path) -> None:
    subprocess.run(arguments, cwd=cwd, check=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)


def valid_order(root: Path, work_order_id: str = "WO-test", lane: str = "constitution-enforcement") -> dict:
    order = build_template(root, lane, work_order_id)
    non_goals = ["Do not implement runtime confinement, external integrations, or any successor architecture slice."]
    order["slice"] = {
        "id": "JSR-024",
        "title": "Versioned Constitution payload — BUILD",
        "outcome_class": "BUILD",
        "objective": "Reject development candidates that omit architecture traceability or explicit AI failure controls.",
        "present_problem": "The foundation gate validates scope and authority but does not preserve the full architecture rationale.",
        "present_evidence": ["giga_control/gate.py validates the v1 work order without structured architecture or AI-control fields."],
        "operator_requirements": ["R-17"],
        "architectural_laws": ["L-04", "L-11"],
        "layers": ["L7"],
        "target_source_hashes": ARCHITECTURE_HASHES,
        "why_needed": "Structured admission is needed because R-17 requires policy to be unavoidable and resistant to prompt drift.",
        "smallest_useful_outcome": "One valid bounded work order passes while malformed architecture and AI-control orders fail closed.",
        "abandonment_safety": "Stopping after this validation increment leaves the previous gate and every existing product workflow usable.",
        "prerequisites": ["The foundation Constitution lock, lane registry, Git hook and receipt mechanism already pass."],
        "current_owner": "Lane 10 Constitution and Enforcement owns deterministic development admission behavior.",
    }
    order["non_goals"] = non_goals
    order["allowed_paths"] = ["giga_control/example.py"]
    order["reuse"] = {
        "searched": ["CONSTITUTION.md, giga_control/gate.py, current tests, the architecture proposal and implementation blueprint."],
        "closest_candidates": ["The existing gate owns admission and receipts but lacks the structured stewardship contract."],
        "decision": "BUILD the versioned Constitution payload by extending the canonical protected gate, not a parallel entrypoint.",
    }
    order["decision_rationale"] = [
        {
            "decision": "Put stewardship validation inside the existing protected deterministic gate.",
            "needed_because": "The operator requires LLM limitations and architecture nuance to be enforced on every official path.",
            "operator_requirement": "R-17",
        }
    ]
    order["assumptions"] = ["The repository gate is the current official integration boundary, not an OS hostile-process sandbox."]
    order["unknowns"] = ["Host-level monotonic enforcement remains a later runtime-reliability slice and is not claimed here."]
    order["acceptance"] = [
        {
            "id": "focused-positive",
            "category": "focused-positive",
            "proves": "A fully structured, bounded and architecture-bound work order validates successfully.",
            "argv": ["python3", "-m", "unittest", "tests.constitution.test_stewardship_v3.StructuredStewardshipAdversarialTests.test_structured_rationale_does_not_require_magic_phrase"],
            "cwd": ".",
            "expected_exit_code": 0,
            "timeout_seconds": 30,
        },
        {
            "id": "focused-negative",
            "category": "negative",
            "proves": "The focused negative suite rejects missing, unknown and internally inconsistent controls.",
            "argv": ["python3", "-m", "unittest", "tests.constitution.test_stewardship_v3.StructuredStewardshipAdversarialTests"],
            "cwd": ".",
            "expected_exit_code": 0,
            "timeout_seconds": 30,
        },
        {
            "id": "full-regression",
            "category": "regression",
            "proves": "The complete repository suite preserves every previously verified foundation behavior.",
            "argv": ["python3", "-m", "unittest", "tests.constitution.test_gate.FoundationTests"],
            "cwd": ".",
            "expected_exit_code": 0,
            "timeout_seconds": 30,
        },
    ]
    order["ai_controls"] = {
        "hallucination": {
            "claims_require": ["A repository path plus executable evidence is required before any capability is called implemented."],
            "inspected_sources": ["The protected gate, its tests, the Constitution and both hash-bound architecture sources."],
            "falsifier": "Discovery of an accepted official path that omits the structured validation disproves unavoidability.",
        },
        "scope_drift": {
            "excluded_work": non_goals,
            "stop_when": ["Stop if the change requires a runtime service, external authority, or an unrelated product modification."],
        },
        "context_bloat": {
            "required_sources": ["CONSTITUTION.md", "giga_control/gate.py", "the two ratified architecture sources"],
            "excluded_sources": ["Vault contents, product repositories and unrelated historical reports are excluded."],
            "nuance_anchors": [
                "R-17 requires an unavoidable policy path.",
                "L-04 forbids an official constitutional bypass.",
                "L-11 prevents self-improvement from rewriting its judge.",
                "L7 is the deterministic constitutional policy and authority layer.",
            ],
            "max_source_files": 8,
        },
        "tunnel_vision": {
            "counterevidence": "A valid bounded order rejected by the structure is evidence the policy is disproportionate or malformed.",
            "stop_or_change_if": "Stop and revise if adversarial tests show a false accept, false reject, replay, or legacy entrypoint bypass.",
        },
        "failure_forecast": [
            {
                "failure": "A malformed work order is admitted through an overlooked entrypoint.",
                "safe_state": "The candidate remains uncommitted and the last verified foundation stays usable.",
                "proof_id": "focused-negative",
            }
        ],
        "sanity_check": {
            "claim": "The smallest valid order passes and malformed variants fail without requiring network or personal data.",
            "falsifier": "Any malformed variant passes or the valid minimal order fails under either official entrypoint.",
            "proof_ids": ["focused-positive", "focused-negative"],
        },
    }
    order["migration_hazards"] = {
        "H1": "incomplete quarantine: no scheduler, provider path or state root is removed by this validation-only candidate.",
        "H2": "mechanical major change: no Python, schema, provider or OS major migration is hidden inside this slice.",
        "H3": "runtime/deployment drift: the root launcher and runtime pins remain unchanged by this repository-bound slice.",
        "H4": "route-class gaps: both normal and legacy Python entrypoints are tested; no runtime stimulus routing changes.",
        "H5": "stateful-store upgrade: no live database or stateful store is changed by this validation-only candidate.",
        "H6": "transitional weak state: host-level hostile-process resistance stays a named residual risk, not a completion claim.",
        "H7": "stacked work: the isolated candidate starts from the recorded trunk and requires independent assurance before integration.",
        "H8": "living-doc drift: instructions, template, policy identity and locked tests change atomically with the gate.",
    }
    order["rollback"] = {
        "strategy": "git-revert-candidate",
        "steps": ["Revert the exact isolated candidate commit through the independent integration boundary."],
        "preserves": "Retain the recorded preflight starting commit as the last known-good foundation state.",
        "verification_proof_ids": ["full-regression"],
    }
    order["next_step"] = {"propose_only": True, "successor_authorized": False}
    return order


class FoundationTests(unittest.TestCase):
    def test_current_foundation_and_locks_pass(self) -> None:
        result = check_foundation(ROOT)
        self.assertEqual(result["status"], "PASS")
        self.assertEqual(result["lanes"], 10)
        self.assertEqual(result["development_stewardship"]["work_order_schema"], "giga-v2.work-order.v2")

    def test_changed_constitution_fails_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = Path(temporary) / "project"
            shutil.copytree(ROOT, copy, ignore=shutil.ignore_patterns(".git", "__pycache__", ".tmp"))
            (copy / "CONSTITUTION.md").write_text("tampered\n", encoding="utf-8")
            with self.assertRaisesRegex(GateError, "lock|version"):
                check_foundation(copy)


class WorkOrderTests(unittest.TestCase):
    def validation_time(self, order: dict) -> dt.datetime:
        return dt.datetime.fromisoformat(order["created_at"].replace("Z", "+00:00")) + dt.timedelta(minutes=1)

    def test_structured_order_is_bound_and_valid(self) -> None:
        order = valid_order(ROOT)
        validated = validate_work_order(order, ROOT, now=self.validation_time(order))
        self.assertEqual(validated["constitution"], constitution_identity(ROOT))

    def test_more_than_24_hours_is_rejected(self) -> None:
        order = valid_order(ROOT)
        order["max_runtime_seconds"] = 86_401
        with self.assertRaisesRegex(GateError, "86400"):
            validate_work_order(order, ROOT, now=self.validation_time(order))

    def test_more_than_default_requires_operator_override(self) -> None:
        order = valid_order(ROOT)
        order["max_runtime_seconds"] = 20_000
        with self.assertRaisesRegex(GateError, "operator_time_override"):
            validate_work_order(order, ROOT, now=self.validation_time(order))

    def test_cross_lane_path_is_rejected(self) -> None:
        order = valid_order(ROOT)
        order["allowed_paths"] = ["src/giga_vault/"]
        with self.assertRaisesRegex(GateError, "outside lane"):
            validate_work_order(order, ROOT, now=self.validation_time(order))

    def test_foundation_authority_is_denied(self) -> None:
        order = valid_order(ROOT)
        order["authority"]["external_writes"] = True
        with self.assertRaisesRegex(GateError, "deny"):
            validate_work_order(order, ROOT, now=self.validation_time(order))


class ReceiptTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temporary = tempfile.TemporaryDirectory()
        self.root = Path(self.temporary.name) / "project"
        shutil.copytree(ROOT, self.root, ignore=shutil.ignore_patterns(".git", "__pycache__", ".tmp"))
        run("git", "init", "-b", "main", cwd=self.root)
        run("git", "config", "user.name", "GIGA Test", cwd=self.root)
        run("git", "config", "user.email", "giga-test@local.invalid", cwd=self.root)
        run("git", "add", ".", cwd=self.root)
        run("git", "commit", "-m", "baseline", cwd=self.root)

    def tearDown(self) -> None:
        self.temporary.cleanup()

    def make_order(self, work_order_id: str) -> Path:
        order = valid_order(self.root, work_order_id)
        order["allowed_paths"] = ["giga_control/candidate.py"]
        path = self.root / "work_orders" / f"{work_order_id}.json"
        write_object(path, order)
        return path

    def test_admit_verify_commit_and_attest_real_candidate(self) -> None:
        order_path = self.make_order("WO-pass")
        preflight_path = admit(self.root, order_path)
        (self.root / "giga_control/candidate.py").write_text("VALUE = 1\n", encoding="utf-8")
        completion_path, passed = verify(self.root, order_path, preflight_path)
        self.assertTrue(passed)
        completion = load_object(completion_path)
        self.assertEqual(completion["status"], "PASS")
        self.assertTrue(valid_self_hash(completion))
        run("git", "add", ".", cwd=self.root)
        run("git", "commit", "-m", "candidate", cwd=self.root)
        candidate = subprocess.run(
            ["git", "rev-parse", "HEAD"], cwd=self.root, check=True, stdout=subprocess.PIPE
        ).stdout.decode().strip()
        attestation_path = attest_candidate(self.root, order_path, preflight_path, completion_path, candidate)
        attestation = check_attestation(self.root, attestation_path)
        self.assertEqual(attestation["candidate_commit"], candidate)

    def test_out_of_scope_change_is_rejected(self) -> None:
        order_path = self.make_order("WO-reject")
        preflight_path = admit(self.root, order_path)
        (self.root / "giga_control/candidate.py").write_text("VALUE = 1\n", encoding="utf-8")
        (self.root / "README.md").write_text("unauthorised change\n", encoding="utf-8")
        completion_path, passed = verify(self.root, order_path, preflight_path)
        self.assertFalse(passed)
        receipt = load_object(completion_path)
        self.assertIn("README.md", receipt["rejected_paths"])

    def test_fabricated_attestation_for_nonexistent_order_is_rejected(self) -> None:
        candidate = subprocess.run(
            ["git", "rev-parse", "HEAD"], cwd=self.root, check=True, stdout=subprocess.PIPE
        ).stdout.decode().strip()
        tree = subprocess.run(
            ["git", "rev-parse", "HEAD^{tree}"], cwd=self.root, check=True, stdout=subprocess.PIPE
        ).stdout.decode().strip()
        forged = self_bound(
            {
                "schema": "giga-v2.candidate-attestation.v1",
                "status": "PASS",
                "recorded_at": "2026-08-20T00:00:00Z",
                "work_order_id": "WO-never-admitted",
                "work_order_sha256": "0" * 64,
                "preflight_sha256": "1" * 64,
                "completion_sha256": "2" * 64,
                "constitution": constitution_identity(self.root),
                "candidate_commit": candidate,
                "candidate_tree": tree,
                "candidate_payload_sha256": "3" * 64,
                "changed_paths": [],
            }
        )
        path = self.root / "receipts/WO-never-admitted/attestation.json"
        write_object(path, forged)
        with self.assertRaisesRegex(GateError, "cannot load JSON object"):
            check_attestation(self.root, path)


if __name__ == "__main__":
    unittest.main()
