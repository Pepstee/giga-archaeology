from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import shutil
import subprocess
import tempfile
import unittest
from pathlib import Path

from giga_control import gate
from giga_control.gate import (
    AUTHORITY_SOURCE_DIRECTORY,
    DENIED_AMENDMENT_AUTHORITY,
    GateError,
    PORTABLE_AMENDMENT_PATH,
    RATIFIED_BASE_COMMIT,
    BoundSourceSnapshot,
    canonical,
    check_foundation,
    close_bound_authority_snapshot,
    finish_bound_authority_read,
    open_bound_authority_snapshot,
    protected_paths,
    sha256_bytes,
    validate_work_order,
)
from tests.constitution.test_gate import ARCHITECTURE_HASHES, ROOT, valid_order


PROPOSAL_REPOSITORY_PATH = f"{AUTHORITY_SOURCE_DIRECTORY}/{ARCHITECTURE_HASHES[0]}.md"
BLUEPRINT_REPOSITORY_PATH = f"{AUTHORITY_SOURCE_DIRECTORY}/{ARCHITECTURE_HASHES[1]}.md"
IGNORE = shutil.ignore_patterns(".git", "__pycache__", ".tmp")


def relocated_copy(parent: str) -> Path:
    destination = Path(parent).resolve()
    if destination.is_relative_to(ROOT.resolve()):
        raise AssertionError("disposable relocated copies must never nest under the candidate worktree")
    copy = destination / "project"
    shutil.copytree(ROOT, copy, ignore=IGNORE)
    return copy


def git_env(home: Path) -> dict:
    """Hermetic Git environment so clones never touch caller config or caches."""
    return {
        **os.environ,
        "HOME": str(home),
        "TMPDIR": str(home),
        "GIT_CONFIG_NOSYSTEM": "1",
        "GIT_CONFIG_GLOBAL": "/dev/null",
        "GIT_CONFIG_SYSTEM": "/dev/null",
        "LANG": "C",
    }


def base_blob(relative: str) -> bytes:
    return subprocess.run(
        ["git", "show", f"{RATIFIED_BASE_COMMIT}:{relative}"],
        cwd=ROOT,
        check=True,
        stdout=subprocess.PIPE,
        env=git_env(ROOT),
    ).stdout


def policy_self_hash(value: dict) -> str:
    body = dict(value)
    body.pop("policy_sha256", None)
    return sha256_bytes(canonical(body))


def write_json(path: Path, value: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def write_policy_variant(copy: Path, mutate) -> None:
    path = copy / "contracts/constitution/development-stewardship.v3.json"
    value = json.loads(path.read_text(encoding="utf-8"))
    mutate(value)
    value["policy_sha256"] = policy_self_hash(value)
    write_json(path, value)


def duplicate_key_fixture(value: dict, anchor: str) -> str:
    """Render valid JSON, then inject a same-value duplicate key so a
    last-key-wins parser observes exactly the original object."""
    text = json.dumps(value, indent=2, sort_keys=True)
    lines = text.splitlines()
    for index, line in enumerate(lines):
        if line.strip().startswith(f'"{anchor}":'):
            lines.insert(index, line)
            return "\n".join(lines) + "\n"
    raise AssertionError(f"anchor {anchor} not found")


class StructuredStewardshipAdversarialTests(unittest.TestCase):
    def validation_time(self, order: dict) -> dt.datetime:
        return dt.datetime.fromisoformat(order["created_at"].replace("Z", "+00:00")) + dt.timedelta(minutes=1)

    def rejected(self, order: dict, message: str) -> None:
        with self.assertRaisesRegex(GateError, message):
            validate_work_order(order, ROOT, now=self.validation_time(order))

    def test_v1_order_is_rejected(self) -> None:
        order = valid_order(ROOT)
        order["schema"] = "giga-v2.work-order.v1"
        self.rejected(order, "schema")

    def test_nonexistent_catalogue_slice_is_rejected(self) -> None:
        order = valid_order(ROOT)
        order["slice"]["id"] = "JSR-999"
        self.rejected(order, "ratified 1..108")

    def test_catalogue_title_must_match_the_selected_slice(self) -> None:
        order = valid_order(ROOT)
        order["slice"]["title"] = "A fabricated but plausible constitutional implementation title"
        self.rejected(order, "ratified JSR catalogue")

    def test_short_exact_catalogue_title_is_accepted(self) -> None:
        order = valid_order(ROOT)
        order["slice"]["id"] = "JSR-089"
        order["slice"]["title"] = "Plan lifecycle — BUILD"
        validate_work_order(order, ROOT, now=self.validation_time(order))

    def test_unknown_requirement_is_rejected(self) -> None:
        order = valid_order(ROOT)
        order["slice"]["operator_requirements"] = ["R-99"]
        self.rejected(order, "ratified 1..22")

    def test_missing_ai_control_is_rejected(self) -> None:
        order = valid_order(ROOT)
        del order["ai_controls"]["hallucination"]
        self.rejected(order, "missing fields: hallucination")

    def test_scope_exclusions_must_equal_non_goals(self) -> None:
        order = valid_order(ROOT)
        order["ai_controls"]["scope_drift"]["excluded_work"] = ["A different exclusion that hides scope expansion."]
        self.rejected(order, "exactly match non_goals")

    def test_context_ceiling_cannot_be_smaller_than_required_sources(self) -> None:
        order = valid_order(ROOT)
        order["ai_controls"]["context_bloat"]["max_source_files"] = 1
        self.rejected(order, "must cover required_sources")

    def test_nuance_anchor_must_cover_every_selected_architecture_id(self) -> None:
        order = valid_order(ROOT)
        order["ai_controls"]["context_bloat"]["nuance_anchors"] = ["R-17 is retained but the laws and layer vanished."]
        self.rejected(order, "omit selected identifier")

    def test_nuance_anchor_rejects_identifier_substrings(self) -> None:
        order = valid_order(ROOT)
        order["ai_controls"]["context_bloat"]["nuance_anchors"][0] = "R-170 is not the selected requirement."
        self.rejected(order, "omit selected identifier: R-17")

    def test_sanity_check_cannot_cite_an_unknown_proof(self) -> None:
        order = valid_order(ROOT)
        order["ai_controls"]["sanity_check"]["proof_ids"] = ["imaginary-proof"]
        self.rejected(order, "unknown proof")

    def test_failure_forecast_cannot_cite_an_unknown_proof(self) -> None:
        order = valid_order(ROOT)
        order["ai_controls"]["failure_forecast"][0]["proof_id"] = "imaginary-proof"
        self.rejected(order, "unknown proof")

    def test_failure_forecast_cannot_cite_a_positive_proof(self) -> None:
        order = valid_order(ROOT)
        order["ai_controls"]["failure_forecast"][0]["proof_id"] = "focused-positive"
        self.rejected(order, "negative, rollback or system")

    def test_sanity_check_requires_positive_and_negative_evidence(self) -> None:
        order = valid_order(ROOT)
        order["ai_controls"]["sanity_check"]["proof_ids"] = ["focused-positive", "full-regression"]
        self.rejected(order, "both focused-positive and negative")

    def test_missing_negative_category_is_rejected_even_with_misleading_id(self) -> None:
        order = valid_order(ROOT)
        order["acceptance"][1]["category"] = "focused-positive"
        self.rejected(order, "focused-positive, negative")

    def test_placeholder_prose_is_rejected(self) -> None:
        order = valid_order(ROOT)
        order["slice"]["why_needed"] = "Replace with something persuasive enough for admission."
        self.rejected(order, "placeholder")

    def test_real_evidence_may_mention_an_upstream_todo_marker(self) -> None:
        order = valid_order(ROOT)
        order["slice"]["present_evidence"] = [
            "The inspected upstream parser contains a TODO marker at its incomplete quarantine branch."
        ]
        validate_work_order(order, ROOT, now=self.validation_time(order))

    def test_inline_no_op_acceptance_command_is_rejected(self) -> None:
        order = valid_order(ROOT)
        order["acceptance"][0]["argv"] = ["python3", "-c", "raise SystemExit(0)"]
        self.rejected(order, "inline interpreter code")

    def test_hazard_key_cannot_hide_an_unrelated_meaning(self) -> None:
        order = valid_order(ROOT)
        order["migration_hazards"]["H1"] = "This unrelated statement is long enough but ignores quarantine entirely."
        self.rejected(order, "canonical hazard meaning")

    def test_rollback_cannot_be_unstructured_prose(self) -> None:
        order = valid_order(ROOT)
        order["rollback"] = "Just undo it somehow while preserving everything important."
        self.rejected(order, "structured object")

    def test_rollback_requires_system_level_verification(self) -> None:
        order = valid_order(ROOT)
        order["rollback"]["verification_proof_ids"] = ["focused-positive"]
        self.rejected(order, "rollback, regression or system")

    def test_structured_rationale_does_not_require_magic_phrase(self) -> None:
        order = valid_order(ROOT)
        order["decision_rationale"][0]["needed_because"] = (
            "The observed legacy entrypoint bypass requires one canonical protected validator."
        )
        validate_work_order(order, ROOT, now=self.validation_time(order))


class AuthoritySourceDescriptorTests(unittest.TestCase):
    """Closed-descriptor negatives; every variant recomputes the policy self-hash."""

    def rejected_variant(self, copy: Path, message: str) -> None:
        with self.assertRaisesRegex(GateError, message):
            check_foundation(copy)

    def test_active_v3_foundation_passes_without_any_upstream_path(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            result = check_foundation(copy)
            self.assertEqual("PASS", result["status"])
            self.assertNotIn("upstream_path", (copy / "contracts/constitution/development-stewardship.v3.json").read_text(encoding="utf-8"))

    def test_role_swap_rejects_after_recomputed_self_hash(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            write_policy_variant(
                copy,
                lambda value: value["architecture_target"].__setitem__(
                    "sources", list(reversed(value["architecture_target"]["sources"]))
                ),
            )
            self.rejected_variant(copy, "role does not match the ratified descriptor order")

    def test_duplicate_role_rejects_after_recomputed_self_hash(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)

            def duplicate_role(value: dict) -> None:
                sources = value["architecture_target"]["sources"]
                sources[1] = dict(sources[0])

            write_policy_variant(copy, duplicate_role)
            self.rejected_variant(copy, "role does not match the ratified descriptor order|hash differs")

    def test_unknown_descriptor_field_rejects_after_recomputed_self_hash(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)

            def add_field(value: dict) -> None:
                value["architecture_target"]["sources"][0]["note"] = "attacker annotation"

            write_policy_variant(copy, add_field)
            self.rejected_variant(copy, "unknown fields: note")

    def test_absolute_repository_path_rejects_after_recomputed_self_hash(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)

            def absolutize(value: dict) -> None:
                value["architecture_target"]["sources"][0]["repository_path"] = "/etc/passwd"

            write_policy_variant(copy, absolutize)
            self.rejected_variant(copy, "must be a normal relative path|escapes the owned authority-source directory")

    def test_escaped_repository_path_rejects_after_recomputed_self_hash(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)

            def escape(value: dict) -> None:
                value["architecture_target"]["sources"][0][
                    "repository_path"
                ] = f"{AUTHORITY_SOURCE_DIRECTORY}/../sha256/{ARCHITECTURE_HASHES[0]}.md"

            write_policy_variant(copy, escape)
            self.rejected_variant(copy, "normal relative path|escapes the owned authority-source directory")

    def test_alternate_repository_directory_rejects_after_recomputed_self_hash(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)

            def relocate(value: dict) -> None:
                value["architecture_target"]["sources"][0][
                    "repository_path"
                ] = f"contracts/authority-sources/{ARCHITECTURE_HASHES[0]}.md"

            write_policy_variant(copy, relocate)
            self.rejected_variant(copy, "escapes the owned authority-source directory")

    def test_changed_source_bytes_with_matching_descriptor_and_self_hash_still_reject(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            target = copy / PROPOSAL_REPOSITORY_PATH
            tampered = target.read_bytes()[:-1] + b"X"
            target.write_bytes(tampered)

            def rebind(value: dict) -> None:
                source = value["architecture_target"]["sources"][0]
                source["sha256"] = sha256_bytes(tampered)
                source["bytes"] = len(tampered)

            write_policy_variant(copy, rebind)
            self.rejected_variant(copy, "hash differs from the ratified identity")

    def test_coordinated_version_rehash_still_rejects_foundation(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            policy_path = copy / "contracts/constitution/development-stewardship.v3.json"
            value = json.loads(policy_path.read_text(encoding="utf-8"))
            value["version"] = "3.0.1"
            value["policy_sha256"] = policy_self_hash(value)
            write_json(policy_path, value)
            record_path = copy / PORTABLE_AMENDMENT_PATH
            record = json.loads(record_path.read_text(encoding="utf-8"))
            record["successor_policy_identity"]["version"] = "3.0.1"
            record["successor_policy_identity"]["policy_sha256"] = value["policy_sha256"]
            for entry in record["candidate_manifest"]:
                if entry["path"] == "contracts/constitution/development-stewardship.v3.json":
                    entry["sha256"] = sha256_bytes(policy_path.read_bytes())
            body = dict(record)
            body.pop("amendment_sha256", None)
            record["amendment_sha256"] = sha256_bytes(canonical(body))
            write_json(record_path, record)
            with self.assertRaisesRegex(GateError, "version must be exactly 3.0.0"):
                check_foundation(copy)

    def test_coordinated_decisive_policy_authority_rehash_still_rejects(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            policy_path = copy / "contracts/constitution/development-stewardship.v3.json"
            policy = json.loads(policy_path.read_text(encoding="utf-8"))
            policy["recorded_at"] = "2099-12-31T23:59:59Z"
            policy["goal_authority"]["thread_id"] = "attacker-controlled-thread"
            policy["stewardship"]["automatic_successor_authority"] = True
            policy["stewardship"]["parallel_slice_limit"] = 999
            policy["policy_sha256"] = policy_self_hash(policy)
            write_json(policy_path, policy)

            record_path = copy / PORTABLE_AMENDMENT_PATH
            record = json.loads(record_path.read_text(encoding="utf-8"))
            record["successor_policy_identity"]["policy_sha256"] = policy["policy_sha256"]
            for entry in record["candidate_manifest"]:
                if entry["path"] == "contracts/constitution/development-stewardship.v3.json":
                    entry["sha256"] = sha256_bytes(policy_path.read_bytes())
            body = dict(record)
            body.pop("amendment_sha256", None)
            record["amendment_sha256"] = sha256_bytes(canonical(body))
            write_json(record_path, record)

            with self.assertRaisesRegex(GateError, "ratified v3 identity"):
                check_foundation(copy)

    def test_each_decisive_policy_identity_substitution_rejects_after_full_rehash(self) -> None:
        mutations = (
            lambda policy: policy.__setitem__("recorded_at", "2099-12-31T23:59:59Z"),
            lambda policy: policy["goal_authority"].__setitem__(
                "thread_id", "attacker-controlled-thread"
            ),
            lambda policy: policy["stewardship"].__setitem__(
                "automatic_successor_authority", True
            ),
            lambda policy: policy["stewardship"].__setitem__("parallel_slice_limit", 999),
        )
        for mutate in mutations:
            with self.subTest(mutate=mutate), tempfile.TemporaryDirectory() as temporary:
                copy = relocated_copy(temporary)
                policy_path = copy / "contracts/constitution/development-stewardship.v3.json"
                policy = json.loads(policy_path.read_text(encoding="utf-8"))
                mutate(policy)
                policy["policy_sha256"] = policy_self_hash(policy)
                write_json(policy_path, policy)

                record_path = copy / PORTABLE_AMENDMENT_PATH
                record = json.loads(record_path.read_text(encoding="utf-8"))
                record["successor_policy_identity"]["policy_sha256"] = policy[
                    "policy_sha256"
                ]
                for entry in record["candidate_manifest"]:
                    if entry["path"] == "contracts/constitution/development-stewardship.v3.json":
                        entry["sha256"] = sha256_bytes(policy_path.read_bytes())
                body = dict(record)
                body.pop("amendment_sha256", None)
                record["amendment_sha256"] = sha256_bytes(canonical(body))
                write_json(record_path, record)

                with self.assertRaisesRegex(GateError, "ratified v3 identity"):
                    check_foundation(copy)

    def test_v2_only_policy_has_no_compatibility_fallback(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            legacy = base_blob("contracts/constitution/development-stewardship.v2.json")
            (copy / "contracts/constitution/development-stewardship.v3.json").write_bytes(legacy)
            self.rejected_variant(copy, "not active v3")

    def test_restored_v2_file_at_legacy_path_cannot_replace_v3(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            (copy / "contracts/constitution/development-stewardship.v3.json").unlink()
            legacy = base_blob("contracts/constitution/development-stewardship.v2.json")
            (copy / "contracts/constitution/development-stewardship.v2.json").write_bytes(legacy)
            self.rejected_variant(copy, "foundation files missing")

    def test_partial_migration_tree_fails_foundation(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            (copy / BLUEPRINT_REPOSITORY_PATH).unlink()
            self.rejected_variant(copy, "missing, linked or unreadable")


class AuthoritySourceReadTests(unittest.TestCase):
    def test_tampered_same_size_source_rejects_on_identity(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            target = copy / BLUEPRINT_REPOSITORY_PATH
            data = bytearray(target.read_bytes())
            data[0] ^= 0x20
            target.write_bytes(bytes(data))
            with self.assertRaisesRegex(GateError, "differs from the ratified identity"):
                check_foundation(copy)

    def test_size_deviation_rejects_before_reading(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            target = copy / BLUEPRINT_REPOSITORY_PATH
            target.write_bytes(target.read_bytes() + b"\n")
            with self.assertRaisesRegex(GateError, "size differs from its bound descriptor"):
                check_foundation(copy)

    def test_source_symlink_rejects_even_with_identical_bytes(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            target = copy / PROPOSAL_REPOSITORY_PATH
            identical = Path(temporary) / "identical.md"
            identical.write_bytes(target.read_bytes())
            target.unlink()
            os.symlink(identical, target)
            with self.assertRaisesRegex(GateError, "missing, linked or unreadable"):
                check_foundation(copy)

    def test_parent_symlink_rejects_even_with_identical_files(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            source_dir = copy / AUTHORITY_SOURCE_DIRECTORY
            mirror = Path(temporary) / "mirror"
            shutil.copytree(source_dir, mirror)
            shutil.rmtree(source_dir)
            os.symlink(mirror, source_dir)
            with self.assertRaisesRegex(GateError, "missing, linked or unreadable"):
                check_foundation(copy)

    def test_hardlink_rejects_even_with_identical_bytes(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            target = copy / PROPOSAL_REPOSITORY_PATH
            twin = Path(temporary) / "twin.md"
            twin.write_bytes(target.read_bytes())
            target.unlink()
            os.link(twin, target)
            with self.assertRaisesRegex(GateError, "exactly one hard link"):
                check_foundation(copy)

    def test_byte_identical_inode_replacement_during_or_after_open_rejects(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            relative = PROPOSAL_REPOSITORY_PATH
            snapshot: BoundSourceSnapshot = open_bound_authority_snapshot(copy, relative, 65781)
            try:
                original = os.fstat(snapshot.file_fd)
                replacement = Path(temporary) / "replacement.md"
                replacement.write_bytes((copy / relative).read_bytes())
                os.utime(replacement, ns=(original.st_atime_ns, original.st_mtime_ns))
                os.replace(replacement, copy / relative)
                with self.assertRaisesRegex(GateError, "substituted|changed while reading|was replaced"):
                    finish_bound_authority_read(snapshot)
            finally:
                close_bound_authority_snapshot(snapshot)

    def test_snapshot_read_returns_exact_ratified_bytes(self) -> None:
        snapshot = open_bound_authority_snapshot(ROOT, BLUEPRINT_REPOSITORY_PATH, 97251)
        try:
            data = finish_bound_authority_read(snapshot)
        finally:
            close_bound_authority_snapshot(snapshot)
        self.assertEqual(97251, len(data))
        self.assertEqual(ARCHITECTURE_HASHES[1], sha256_bytes(data))

    def test_missing_source_rejects_as_gate_error_not_oserror(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            (copy / PROPOSAL_REPOSITORY_PATH).unlink()
            try:
                check_foundation(copy)
            except GateError as exc:
                self.assertIn("missing, linked or unreadable", str(exc))
            except OSError as exc:
                self.fail(f"filesystem error leaked through the gate seam: {exc}")
            else:
                self.fail("missing authority source was accepted")


class PortableAuthorityAmendmentTests(unittest.TestCase):
    def record(self) -> dict:
        return json.loads((ROOT / PORTABLE_AMENDMENT_PATH).read_text(encoding="utf-8"))

    def write_record_variant(self, copy: Path, mutate) -> None:
        path = copy / PORTABLE_AMENDMENT_PATH
        value = json.loads(path.read_text(encoding="utf-8"))
        mutate(value)
        body = dict(value)
        claimed = body.pop("amendment_sha256", None)
        body.pop("amendment_sha256", None)
        value["amendment_sha256"] = sha256_bytes(canonical(body))
        del claimed
        write_json(path, value)

    def test_record_is_self_bound_exactly_by_the_specified_formula(self) -> None:
        record = self.record()
        body = dict(record)
        claimed = body.pop("amendment_sha256")
        self.assertEqual(claimed, sha256_bytes(canonical(body)))

    def test_manifest_excludes_the_amendment_itself_and_matches_the_allowlist(self) -> None:
        record = self.record()
        paths = [entry["path"] for entry in record["candidate_manifest"]]
        self.assertNotIn(PORTABLE_AMENDMENT_PATH, paths)
        self.assertEqual(len(paths), len(set(paths)))
        self.assertEqual(sorted(paths), paths)
        expected = sorted(gate.CANDIDATE_ALLOWLIST_ACTIONS)
        self.assertEqual(len(expected), 14)
        self.assertEqual(len(paths), 13)

    def test_add_modify_entries_match_worktree_mode_and_bytes(self) -> None:
        record = self.record()
        for entry in record["candidate_manifest"]:
            if entry["action"] == "delete":
                continue
            target = ROOT / entry["path"]
            observed_mode = "100755" if target.stat().st_mode & 0o111 else "100644"
            self.assertEqual(entry["mode"], observed_mode, entry["path"])
            self.assertEqual(entry["sha256"], sha256_bytes(target.read_bytes()), entry["path"])

    def test_delete_entries_bind_the_exact_base_blob_mode_and_bytes(self) -> None:
        record = self.record()
        for entry in record["candidate_manifest"]:
            if entry["action"] != "delete":
                continue
            listing = subprocess.run(
                ["git", "ls-tree", RATIFIED_BASE_COMMIT, "--", entry["path"]],
                cwd=ROOT,
                check=True,
                stdout=subprocess.PIPE,
            ).stdout.decode().strip()
            metadata, listed = listing.split("\t", 1)
            mode, _kind, object_id = metadata.split()
            self.assertEqual(listed, entry["path"])
            self.assertEqual(entry["mode"], mode)
            blob = subprocess.run(
                ["git", "cat-file", "blob", object_id], cwd=ROOT, check=True, stdout=subprocess.PIPE
            ).stdout
            self.assertEqual(entry["sha256"], sha256_bytes(blob))

    def test_amendment_carries_no_runtime_or_external_authority(self) -> None:
        record = self.record()
        self.assertFalse(record["reusable"])
        self.assertEqual(DENIED_AMENDMENT_AUTHORITY, record["authority"])

    def test_recorded_at_substitution_rejects_after_recomputed_self_hash(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            self.write_record_variant(
                copy,
                lambda value: value.__setitem__("recorded_at", "2099-12-31T23:59:59Z"),
            )
            with self.assertRaisesRegex(GateError, "recorded_at differs from the ratified provenance"):
                check_foundation(copy)

    def test_every_delete_hash_mutation_rejects_through_the_production_judge(self) -> None:
        for entry in self.record()["candidate_manifest"]:
            if entry["action"] != "delete":
                continue
            for forged in ("0" * 64, sha256_bytes(b"attacker payload")):
                with tempfile.TemporaryDirectory() as temporary:
                    copy = relocated_copy(temporary)

                    def mutate(value: dict, target: str = entry["path"], forged: str = forged) -> None:
                        for item in value["candidate_manifest"]:
                            if item["path"] == target:
                                item["sha256"] = forged

                    self.write_record_variant(copy, mutate)
                    with self.assertRaisesRegex(
                        GateError, "differs from the ratified base blob binding"
                    ):
                        check_foundation(copy)

    def test_delete_mode_mutation_rejects_through_the_production_judge(self) -> None:
        for entry in self.record()["candidate_manifest"]:
            if entry["action"] != "delete":
                continue
            with tempfile.TemporaryDirectory() as temporary:
                copy = relocated_copy(temporary)

                def mutate(value: dict, target: str = entry["path"]) -> None:
                    for item in value["candidate_manifest"]:
                        if item["path"] == target:
                            item["mode"] = "100755"

                self.write_record_variant(copy, mutate)
                with self.assertRaisesRegex(GateError, "differs from the ratified base blob binding"):
                    check_foundation(copy)

    def test_add_modify_leaf_stays_regular_under_the_production_judge(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            victim = copy / BLUEPRINT_REPOSITORY_PATH
            identical = Path(temporary) / "identical.md"
            identical.write_bytes(victim.read_bytes())
            victim.unlink()
            os.symlink(identical, victim)
            with self.assertRaisesRegex(GateError, "missing, linked or unreadable|drifted"):
                check_foundation(copy)

    def test_every_restored_superseded_delete_rejects_foundation(self) -> None:
        for relative in (
            "contracts/constitution/development-stewardship.v2.json",
            "contracts/constitution/local-verification.v1.json",
            "tests/constitution/test_stewardship_v2.py",
        ):
            with tempfile.TemporaryDirectory() as temporary:
                copy = relocated_copy(temporary)
                restored = copy / relative
                restored.parent.mkdir(parents=True, exist_ok=True)
                restored.write_bytes(base_blob(relative))
                with self.assertRaisesRegex(GateError, "superseded delete target must be absent"):
                    check_foundation(copy)

    def test_amendment_read_rejects_substituted_parent_before_external_bytes(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            amendments = copy / "contracts/constitution/amendments"
            mirror = Path(temporary) / "mirror-amendments"
            shutil.copytree(amendments, mirror)
            shutil.rmtree(amendments)
            os.symlink(mirror, amendments)
            with self.assertRaisesRegex(GateError, "missing, linked or unreadable"):
                check_foundation(copy)

    def test_flag_substitution_rejects_even_with_recomputed_self_hash(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            self.write_record_variant(copy, lambda value: value.update(reusable=True))
            with self.assertRaisesRegex(GateError, "may not be reusable"):
                check_foundation(copy)

    def test_base_binding_substitution_rejects_even_with_recomputed_self_hash(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)

            def rebase(value: dict) -> None:
                value["base"] = {"commit": "f" * 40, "tree": "e" * 40}

            self.write_record_variant(copy, rebase)
            with self.assertRaisesRegex(GateError, "base binding is stale"):
                check_foundation(copy)

    def test_successor_identity_substitution_rejects_against_the_active_policy(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)

            def swap(value: dict) -> None:
                value["successor_policy_identity"]["policy_sha256"] = value["prior_policy_identity"]["policy_sha256"]

            self.write_record_variant(copy, swap)
            with self.assertRaisesRegex(GateError, "successor policy identity differs"):
                check_foundation(copy)

    def test_candidate_manifest_substitution_rejects_even_with_recomputed_self_hash(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)

            def forge(value: dict) -> None:
                for entry in value["candidate_manifest"]:
                    if entry["action"] == "modify":
                        entry["sha256"] = sha256_bytes(b"attacker payload")
                        break

            self.write_record_variant(copy, forge)
            with self.assertRaisesRegex(GateError, "drifted from its amendment binding"):
                check_foundation(copy)

    def test_coordinated_broad_dev_grant_and_manifest_rehash_still_rejects(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            runner_path = copy / "giga_control/extensions/local_verify.py"
            exact_rule = '(allow file-read-data (literal "/dev/fd"))'
            broad_rule = '(allow file-read-data (subpath "/dev"))'
            runner_text = runner_path.read_text(encoding="utf-8")
            self.assertEqual(1, runner_text.count(exact_rule))
            runner_path.write_text(runner_text.replace(exact_rule, broad_rule), encoding="utf-8")

            record_path = copy / PORTABLE_AMENDMENT_PATH
            record = json.loads(record_path.read_text(encoding="utf-8"))
            for entry in record["candidate_manifest"]:
                if entry["path"] == "giga_control/extensions/local_verify.py":
                    entry["sha256"] = sha256_bytes(runner_path.read_bytes())
                    break
            else:
                self.fail("local verifier is absent from the candidate manifest")
            body = dict(record)
            body.pop("amendment_sha256", None)
            record["amendment_sha256"] = sha256_bytes(canonical(body))
            write_json(record_path, record)

            with self.assertRaisesRegex(GateError, "ratified portable profile"):
                check_foundation(copy)

    def test_manifest_including_the_amendment_itself_rejects(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)

            def self_include(value: dict) -> None:
                value["candidate_manifest"].append(
                    {
                        "action": "add",
                        "mode": "100644",
                        "path": PORTABLE_AMENDMENT_PATH,
                        "sha256": sha256_bytes((ROOT / PORTABLE_AMENDMENT_PATH).read_bytes()),
                    }
                )
                value["candidate_manifest"].sort(key=lambda entry: entry["path"])

            self.write_record_variant(copy, self_include)
            with self.assertRaisesRegex(GateError, "allowlist minus the amendment record itself|action differs"):
                check_foundation(copy)

    def test_duplicate_raw_object_key_in_amendment_rejects_recursively(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            record_path = copy / PORTABLE_AMENDMENT_PATH
            poisoned = duplicate_key_fixture(self.record(), "reusable")
            record_path.write_text(poisoned, encoding="utf-8")
            with self.assertRaisesRegex(GateError, "duplicate JSON object key"):
                check_foundation(copy)


class StrictAuthorityJsonTests(unittest.TestCase):
    def test_shadow_key_in_stewardship_v3_rejects_when_lenient_parse_would_match(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            policy_path = copy / "contracts/constitution/development-stewardship.v3.json"
            value = json.loads(policy_path.read_text(encoding="utf-8"))
            poisoned = duplicate_key_fixture(value, "status")
            self.assertEqual(value, json.loads(poisoned))
            policy_path.write_text(poisoned, encoding="utf-8")
            with self.assertRaisesRegex(GateError, "duplicate JSON object key"):
                check_foundation(copy)

    def test_shadow_key_at_nested_depth_in_sources_rejects(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            policy_path = copy / "contracts/constitution/development-stewardship.v3.json"
            value = json.loads(policy_path.read_text(encoding="utf-8"))
            poisoned = duplicate_key_fixture(value, "bytes")
            self.assertEqual(value, json.loads(poisoned))
            policy_path.write_text(poisoned, encoding="utf-8")
            with self.assertRaisesRegex(GateError, "duplicate JSON object key"):
                check_foundation(copy)

    def test_shadow_key_in_local_verification_contract_rejects_strictly(self) -> None:
        from giga_control.extensions import local_verify

        with tempfile.TemporaryDirectory() as temporary:
            root = Path(temporary)
            contract_path = root / local_verify.CONTRACT_PATH
            contract_path.parent.mkdir(parents=True)
            value = json.loads((ROOT / local_verify.CONTRACT_PATH).read_text(encoding="utf-8"))
            poisoned = duplicate_key_fixture(value, "selection_policy")
            self.assertEqual(value, json.loads(poisoned))
            contract_path.write_text(poisoned, encoding="utf-8")
            with self.assertRaisesRegex(local_verify.LocalVerificationError, "missing or invalid"):
                local_verify.load_contract(root)

    def test_parser_rejects_duplicates_at_every_depth_directly(self) -> None:
        from giga_control.gate import parse_strict_json

        for text in (
            '{"a": 1, "a": 2}',
            '{"outer": {"b": 1, "b": 0}}',
            '{"list": [{"c": true}, {"d": 1, "d": 2}]}',
        ):
            with self.assertRaisesRegex(GateError, "duplicate JSON object key"):
                parse_strict_json(text, "probe")


class PortabilityAndConsumptionTests(unittest.TestCase):
    def test_active_policy_and_verification_contract_contain_no_personal_absolute_path(self) -> None:
        for relative in (
            "contracts/constitution/development-stewardship.v3.json",
            "contracts/constitution/local-verification.v2.json",
        ):
            data = (ROOT / relative).read_bytes()
            self.assertNotIn(b"/Users/", data, relative)
            self.assertNotIn(b"giga-user", data, relative)

    def test_generated_judge_and_runner_contain_no_external_architecture_literal(self) -> None:
        gate_text = (ROOT / "giga_control/gate.py").read_text(encoding="utf-8")
        runner_text = (ROOT / "giga_control/extensions/local_verify.py").read_text(encoding="utf-8")
        for text in (gate_text, runner_text):
            self.assertNotIn("/Users/", text)
            self.assertNotIn("giga-user/architecture", text)
            self.assertNotIn("upstream_path", text)
        self.assertNotIn("architecture-index", runner_text)
        self.assertNotIn("architecture-index", gate_text)

    def test_architecture_index_is_not_consumed_as_current_availability_source(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            (copy / "programme/architecture-index.json").unlink()
            result = check_foundation(copy)
            self.assertEqual("PASS", result["status"])

    def test_repository_owned_descriptors_override_any_index_state(self) -> None:
        index = json.loads((ROOT / "programme/architecture-index.json").read_text(encoding="utf-8"))
        self.assertTrue(any(s.get("availability") == "EXTERNAL_HASH_ONLY_PENDING_JSR-005" for s in index["target_sources"]))
        policy = json.loads((ROOT / "contracts/constitution/development-stewardship.v3.json").read_text(encoding="utf-8"))
        descriptors = policy["architecture_target"]["sources"]
        self.assertEqual({"sovereign-architecture", "implementation-blueprint"}, {s["role"] for s in descriptors})
        for source in descriptors:
            embedded = ROOT / source["repository_path"]
            self.assertTrue(embedded.is_file())
            self.assertEqual(source["sha256"], sha256_bytes(embedded.read_bytes()))

    def test_protected_registry_and_tuple_track_v3_surfaces(self) -> None:
        protected = protected_paths(ROOT)
        for expected in (
            "contracts/constitution/development-stewardship.v3.json",
            "contracts/constitution/authority-sources",
            "contracts/constitution/amendments",
            "tests/constitution/test_stewardship_v3.py",
        ):
            self.assertIn(expected, protected)
        self.assertNotIn("contracts/constitution/development-stewardship.v2.json", protected)
        self.assertNotIn("tests/constitution/test_stewardship_v2.py", protected)
        registry = json.loads((ROOT / "control/protected-paths.json").read_text(encoding="utf-8"))
        self.assertNotIn("contracts/constitution/local-verification.v1.json", registry["paths"])

    def test_protected_hook_has_no_bootstrap_environment_or_amendment_bypass(self) -> None:
        gate_text = (ROOT / "giga_control/gate.py").read_text(encoding="utf-8")
        hook_text = (ROOT / ".githooks/pre-commit").read_text(encoding="utf-8")
        self.assertIn("git show HEAD:giga_control/gate.py", hook_text)
        self.assertNotIn("GIGA_OPERATOR_BOOTSTRAP", gate_text)
        self.assertNotIn("getenv", gate_text)
        self.assertNotIn("environ.get(\"GIGA_PROTECTED\")", gate_text)
        import inspect

        for function in (gate.admit, gate.verify, gate.validate_work_order):
            self.assertNotIn("amendment", inspect.getsource(function))
        self.assertEqual(
            {"external_writes": False, "future_constitution_amendments": False, "identity_representation": False,
             "irreversible_actions": False, "protected_integration": False, "runtime_deployment": False,
             "spending": False, "vault_access": False},
            gate.DENIED_AMENDMENT_AUTHORITY,
        )


class CandidatePreparationDiffTests(unittest.TestCase):
    DELETES = (
        "contracts/constitution/development-stewardship.v2.json",
        "contracts/constitution/local-verification.v1.json",
        "tests/constitution/test_stewardship_v2.py",
    )

    def candidate_repo(self, parent: str) -> Path:
        destination = Path(parent).resolve()
        if destination.is_relative_to(ROOT.resolve()):
            raise AssertionError("disposable candidate repos must never nest under the candidate worktree")
        repo = destination / "repo"
        subprocess.run(
            ["git", "clone", "--quiet", "--no-hardlinks", "--no-local", str(ROOT), str(repo)],
            check=True,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=git_env(destination),
        )
        skip = {".git", ".tmp", "__pycache__"}
        for source in ROOT.rglob("*"):
            if any(part in skip for part in source.relative_to(ROOT).parts):
                continue
            target = repo / source.relative_to(ROOT)
            if source.is_dir():
                target.mkdir(parents=True, exist_ok=True)
            elif source.is_file():
                target.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(source, target)
        for relative in self.DELETES:
            victim = repo / relative
            if victim.is_symlink() or victim.exists():
                victim.unlink()
        return repo

    def rejected(self, repo: Path, message: str) -> None:
        with self.assertRaisesRegex(GateError, message):
            gate.validate_candidate_preparation_diff(repo)

    def test_exact_candidate_diff_passes_with_full_counts(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            repo = self.candidate_repo(temporary)
            summary = gate.validate_candidate_preparation_diff(repo)
            self.assertEqual(RATIFIED_BASE_COMMIT, summary["head"])
            self.assertEqual({"add": 6, "modify": 5, "delete": 3}, summary["counts"])
            self.assertEqual(14, len(summary["changed_paths"]))

    def test_retained_deleted_v2_rejects(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            repo = self.candidate_repo(temporary)
            (repo / "tests/constitution/test_stewardship_v2.py").write_text("retained\n", encoding="utf-8")
            self.rejected(repo, "differs from the ratified allowlist|missing ratified allowlist paths")

    def test_arbitrary_extra_file_rejects(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            repo = self.candidate_repo(temporary)
            (repo / "notes.txt").write_text("extra\n", encoding="utf-8")
            self.rejected(repo, "outside the ratified allowlist")

    def test_omitted_allowlisted_add_rejects(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            repo = self.candidate_repo(temporary)
            (repo / "contracts/constitution/local-verification.v2.json").unlink()
            self.rejected(repo, "missing ratified allowlist paths")

    def test_omitted_delete_target_absence_requirement_is_enforced_by_presence(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            repo = self.candidate_repo(temporary)
            (repo / self.DELETES[1]).write_bytes(b"a43cb3c2\n")
            self.rejected(repo, "still present|differs from the ratified allowlist|missing ratified allowlist")

    def test_mode_change_of_payload_rejects(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            repo = self.candidate_repo(temporary)
            (repo / "giga_control/extensions/local_verify.py").chmod(0o755)
            self.rejected(repo, "differs from its ratified manifest binding|drifted from its amendment binding")

    def test_symlinked_payload_entry_rejects(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            repo = self.candidate_repo(temporary)
            victim = repo / "contracts/constitution/local-verification.v2.json"
            identical = Path(temporary) / "identical.json"
            identical.write_bytes(victim.read_bytes())
            victim.unlink()
            os.symlink(identical, victim)
            self.rejected(repo, "missing, linked or unreadable")

    def test_mutated_payload_rejects(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            repo = self.candidate_repo(temporary)
            with open(repo / "tests/constitution/test_gate.py", "ab") as handle:
                handle.write(b"# mutated\n")
            self.rejected(repo, "differs from its ratified manifest binding|drifted from its amendment binding")

    def test_coordinated_broad_dev_grant_rejects_through_candidate_validator(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            repo = self.candidate_repo(temporary)
            runner_path = repo / "giga_control/extensions/local_verify.py"
            exact_rule = '(allow file-read-data (literal "/dev/fd"))'
            broad_rule = '(allow file-read-data (subpath "/dev"))'
            runner_text = runner_path.read_text(encoding="utf-8")
            self.assertEqual(1, runner_text.count(exact_rule))
            runner_path.write_text(runner_text.replace(exact_rule, broad_rule), encoding="utf-8")

            record_path = repo / PORTABLE_AMENDMENT_PATH
            record = json.loads(record_path.read_text(encoding="utf-8"))
            for entry in record["candidate_manifest"]:
                if entry["path"] == "giga_control/extensions/local_verify.py":
                    entry["sha256"] = sha256_bytes(runner_path.read_bytes())
                    break
            else:
                self.fail("local verifier is absent from the candidate manifest")
            body = dict(record)
            body.pop("amendment_sha256", None)
            record["amendment_sha256"] = sha256_bytes(canonical(body))
            write_json(record_path, record)

            self.rejected(repo, "ratified portable profile")

    def test_advanced_head_rejects_even_with_identical_tree_content(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            repo = self.candidate_repo(temporary)

            def run_git(*args: str) -> None:
                subprocess.run(
                    ["git", "-C", str(repo), *args],
                    check=True,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    env=git_env(Path(temporary).resolve()),
                )

            run_git("add", "-A")
            run_git("-c", "user.name=Candidate", "-c", "user.email=candidate@local.invalid",
                    "commit", "-qm", "advanced-head")
            self.rejected(repo, "exact ratified base HEAD")


class EntrypointAndLockTests(unittest.TestCase):
    def test_normal_and_legacy_module_entrypoints_share_the_v2_gate(self) -> None:
        for module in ("giga_control", "giga_control.gate"):
            result = subprocess.run(
                ["python3", "-m", module, "check"],
                cwd=ROOT,
                check=False,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
            )
            self.assertEqual(result.returncode, 0, result.stderr)
            value = json.loads(result.stdout)
            self.assertEqual(value["development_stewardship"]["work_order_schema"], "giga-v2.work-order.v2")
            self.assertEqual(value["development_stewardship"]["version"], "3.0.0")

    def test_bound_policy_document_tamper_fails_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            (copy / "contracts/constitution/DEVELOPMENT_STEWARDSHIP.md").write_text("tampered\n", encoding="utf-8")
            with self.assertRaisesRegex(GateError, "document binding|payload drifted"):
                check_foundation(copy)

    def test_gate_and_policy_are_protected_without_a_reusable_bootstrap_path(self) -> None:
        protected = protected_paths(ROOT)
        self.assertIn("giga_control/gate.py", protected)
        self.assertIn("contracts/constitution/development-stewardship.v3.json", protected)
        self.assertNotIn("control/operator-bootstrap.lock.json", protected)
        self.assertNotIn("GIGA_OPERATOR_BOOTSTRAP", (ROOT / "giga_control/gate.py").read_text(encoding="utf-8"))

    def test_hook_executes_the_committed_judge_not_working_tree_code(self) -> None:
        hook_text = (ROOT / ".githooks/pre-commit").read_text(encoding="utf-8")
        self.assertIn("git show HEAD:giga_control/gate.py", hook_text)
        self.assertNotIn("python3 -m giga_control hook", hook_text)

    def test_unstaged_protected_registry_substitution_fails_closed(self) -> None:
        with tempfile.TemporaryDirectory() as temporary:
            copy = relocated_copy(temporary)
            registry_path = copy / "control/protected-paths.json"
            registry = json.loads(registry_path.read_text(encoding="utf-8"))
            registry["paths"].remove("giga_control/gate.py")
            registry_path.write_text(json.dumps(registry, indent=2) + "\n", encoding="utf-8")
            with self.assertRaisesRegex(GateError, "judge-bound ratified set"):
                check_foundation(copy)


if __name__ == "__main__":
    unittest.main()
