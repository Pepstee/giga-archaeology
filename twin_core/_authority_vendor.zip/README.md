# GIGA v2

GIGA v2 is the clean construction root for the second iteration of the GIGA/Jarvis sovereign
runtime. It is a local macOS project designed for manual Codex work and bounded autonomous goals.

The existing `/Users/admin/Documents/giga-user` remains the operator's active work corpus and
evidence source. This repository is distinct because it has a different lifecycle: clean baseline,
strict module ownership, isolated candidates and deterministic admission/integration. Existing
systems are adopted through explicit imports or adapters instead of being silently copied.

## Foundation guarantees

- One canonical Constitution with a locked digest
- One registered ownership scope per development lane
- Work orders limited to one objective and 24 hours
- Default denial of Vault access, external writes and irreversible actions
- Hash-bound preflight and completion receipts
- Candidate-bound attestations that reconstruct the admitted work order, receipts, scope and payload
- Direct-argv acceptance commands with timeouts
- Changed-path confinement and protected-path rejection
- Git pre-commit enforcement plus a separate candidate-verification boundary
- Worktree isolation for parallel Codex tasks

The gate controls what may be accepted as official work. It does not pretend that a process with
unrestricted macOS filesystem access cannot make temporary unaccepted edits. Only candidates that
survive the gate are eligible for integration.

## Commands

```bash
python3 -m unittest discover -s tests -p 'test_*.py'
python3 -m giga_control check
python3 -m giga_control template --lane constitution-enforcement --id WO-example
python3 -m giga_control admit --work-order work_orders/WO-example.json
python3 -m giga_control verify \
  --work-order work_orders/WO-example.json \
  --preflight receipts/WO-example/preflight.json
GIGA_WORK_ORDER=work_orders/WO-example.json git commit -m "Implement admitted slice"
python3 -m giga_control attest \
  --work-order work_orders/WO-example.json \
  --preflight receipts/WO-example/preflight.json \
  --completion receipts/WO-example/completion.json \
  --candidate-commit HEAD
python3 -m giga_control check-attestation \
  --attestation receipts/WO-example/attestation.json
```

See `docs/OPERATING_MANUAL.md` for manual and 24-hour goal operation.
